package com.reelcraft.ai

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ReelCraftNavigationUiTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun homeDashboardDisplaysAndNavigatesToCreateProjectForm() {
        // Wait for Splash screen transition (900ms)
        composeTestRule.mainClock.advanceTimeBy(1200)
        composeTestRule.waitForIdle()

        // Verify Arabic default Home Dashboard CTA button is displayed
        composeTestRule.onNodeWithText("إنشاء مشروع فيديو جديد").assertIsDisplayed()
        composeTestRule.onNodeWithText("إنشاء مشروع فيديو جديد").performClick()

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("مشروع فيديو جديد").assertIsDisplayed()
    }
}
