package com.reelcraft.ai

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.reelcraft.ai.data.local.ReelCraftDatabase
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProjectDaoInstrumentedTest {

    private lateinit var database: ReelCraftDatabase

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(
            context,
            ReelCraftDatabase::class.java
        ).allowMainThreadQueries().build()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun insertSearchReorderAndCascadeDeleteInRoom() = runBlocking {
        val projectDao = database.projectDao()
        val sceneDao = database.sceneDao()

        val projectId = projectDao.insertProject(
            VideoProjectEntity(
                title = "أسرار الأهرامات",
                topic = "وثائقي عن الهندسة المصرية القديمة",
                category = "DOCUMENTARY",
                language = "EGYPTIAN_ARABIC",
                targetPlatform = "INSTAGRAM_REELS",
                visualStyle = "DOCUMENTARY",
                durationSeconds = 60,
                openingHook = "إزاي اتبنت الأهرامات بالدقة دي؟",
                fullScript = "إزاي اتبنت الأهرامات بالدقة دي؟ تعال نشوف التفاصيل.",
                createdAt = 1000L,
                updatedAt = 2000L
            )
        )

        sceneDao.insertScenes(
            listOf(
                VideoSceneEntity(
                    projectId = projectId,
                    sceneOrder = 1,
                    voiceOverText = "المشهد الأول",
                    durationSeconds = 15,
                    visualDescription = "لقطة للأهرامات",
                    videoPrompt = "Pyramids of Giza at golden hour"
                ),
                VideoSceneEntity(
                    projectId = projectId,
                    sceneOrder = 2,
                    voiceOverText = "المشهد الثاني",
                    durationSeconds = 15,
                    visualDescription = "لقطة للأحجار الضخمة",
                    videoPrompt = "Close up of ancient limestone blocks"
                )
            )
        )

        val searchHits = projectDao.searchProjects("الأهرامات").first()
        assertEquals(1, searchHits.size)

        // Delete parent project and verify ForeignKey.CASCADE removes child scenes
        projectDao.deleteProjectById(projectId)
        val remainingScenes = sceneDao.getScenesForProject(projectId)
        assertTrue(remainingScenes.isEmpty())
    }
}
