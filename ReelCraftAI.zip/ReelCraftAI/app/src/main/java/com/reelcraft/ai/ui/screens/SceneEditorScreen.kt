package com.reelcraft.ai.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import com.reelcraft.ai.domain.model.ProjectWithScenes
import com.reelcraft.ai.domain.validation.FormValidator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SceneEditorScreen(
    projectWithScenes: ProjectWithScenes?,
    isArabic: Boolean,
    onAddScene: (String, Int, String, String, String, String) -> Unit,
    onUpdateScene: (VideoSceneEntity) -> Unit,
    onDeleteScene: (Long) -> Unit,
    onReorderScenes: (List<VideoSceneEntity>) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scenes = projectWithScenes?.orderedScenes.orEmpty()

    var showAddOrEditDialog by remember { mutableStateOf(false) }
    var editingScene by remember { mutableStateOf<VideoSceneEntity?>(null) }
    var deletingScene by remember { mutableStateOf<VideoSceneEntity?>(null) }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(
            context,
            if (isArabic) "تم النسخ إلى الحافظة" else "Copied to clipboard",
            Toast.LENGTH_SHORT
        ).show()
    }

    if (showAddOrEditDialog) {
        SceneFormDialog(
            initialScene = editingScene,
            isArabic = isArabic,
            onDismiss = {
                showAddOrEditDialog = false
                editingScene = null
            },
            onConfirm = { vo, dur, visual, prompt, transition, sfx ->
                val current = editingScene
                if (current == null) {
                    onAddScene(vo, dur, visual, prompt, transition, sfx)
                } else {
                    onUpdateScene(
                        current.copy(
                            voiceOverText = vo.trim(),
                            durationSeconds = dur,
                            visualDescription = visual.trim(),
                            videoPrompt = prompt.trim(),
                            transition = transition.trim(),
                            soundEffectNotes = sfx.trim()
                        )
                    )
                }
                showAddOrEditDialog = false
                editingScene = null
            }
        )
    }

    if (deletingScene != null) {
        AlertDialog(
            onDismissRequest = { deletingScene = null },
            title = {
                Text(if (isArabic) "حذف المشهد؟" else "Delete Scene?")
            },
            text = {
                Text(
                    if (isArabic) {
                        "هل أنت متأكد من حذف المشهد رقم #${deletingScene?.sceneOrder}؟ سيتم إعادة ترقيم المشاهد المتبقية تلقائياً."
                    } else {
                        "Delete Scene #${deletingScene?.sceneOrder}? Remaining scenes will be automatically renumbered."
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        deletingScene?.let { onDeleteScene(it.id) }
                        deletingScene = null
                    }
                ) {
                    Text(
                        text = if (isArabic) "حذف" else "Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingScene = null }) {
                    Text(if (isArabic) "إلغاء" else "Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(if (isArabic) "محرر المشاهد وأوامر التوليد" else "Scene Editor & Prompts")
                        Text(
                            text = if (isArabic) {
                                "${scenes.size} مشاهد • إجمالي ${projectWithScenes?.totalScenesDurationSeconds ?: 0} ثانية"
                            } else {
                                "${scenes.size} scenes • Total ${projectWithScenes?.totalScenesDurationSeconds ?: 0}s"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isArabic) "رجوع" else "Back"
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingScene = null
                    showAddOrEditDialog = true
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = if (isArabic) "إضافة مشهد" else "Add Scene"
                )
            }
        }
    ) { innerPadding ->
        if (scenes.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isArabic) {
                        "لا توجد مشاهد في هذا المشروع حالياً. اضغط على زر (+) لإضافة مشهد جديد."
                    } else {
                        "No scenes in this project yet. Tap (+) to add your first scene."
                    },
                    style = MaterialTheme.typography.titleMedium
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                itemsIndexed(scenes, key = { _, item -> item.id }) { index, scene ->
                    SceneCardItem(
                        scene = scene,
                        isFirst = index == 0,
                        isLast = index == scenes.lastIndex,
                        isArabic = isArabic,
                        onMoveUp = {
                            if (index > 0) {
                                val mutable = scenes.toMutableList()
                                val swapped = mutable[index - 1]
                                mutable[index - 1] = mutable[index]
                                mutable[index] = swapped
                                onReorderScenes(mutable)
                            }
                        },
                        onMoveDown = {
                            if (index < scenes.lastIndex) {
                                val mutable = scenes.toMutableList()
                                val swapped = mutable[index + 1]
                                mutable[index + 1] = mutable[index]
                                mutable[index] = swapped
                                onReorderScenes(mutable)
                            }
                        },
                        onEdit = {
                            editingScene = scene
                            showAddOrEditDialog = true
                        },
                        onDelete = { deletingScene = scene },
                        onCopyPrompt = { copyToClipboard("Video Prompt", scene.videoPrompt) },
                        onCopyVoiceOver = { copyToClipboard("Voice-Over", scene.voiceOverText) }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(72.dp))
                }
            }
        }
    }
}

@Composable
private fun SceneCardItem(
    scene: VideoSceneEntity,
    isFirst: Boolean,
    isLast: Boolean,
    isArabic: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onCopyPrompt: () -> Unit,
    onCopyVoiceOver: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary
                ) {
                    Text(
                        text = if (isArabic) {
                            "المشهد #${scene.sceneOrder} • ${scene.durationSeconds} ثانية"
                        } else {
                            "Scene #${scene.sceneOrder} • ${scene.durationSeconds}s"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Row {
                    IconButton(onClick = onMoveUp, enabled = !isFirst) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = if (isArabic) "تحريك لأعلى" else "Move Up"
                        )
                    }
                    IconButton(onClick = onMoveDown, enabled = !isLast) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = if (isArabic) "تحريك لأسفل" else "Move Down"
                        )
                    }
                    IconButton(onClick = onEdit) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = if (isArabic) "تعديل" else "Edit"
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = if (isArabic) "حذف" else "Delete",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            Text(
                text = if (isArabic) "التعليق الصوتي (Voice-Over):" else "Voice-Over Narration:",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = scene.voiceOverText,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = if (isArabic) "الوصف البصري:" else "Visual Description:",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = scene.visualDescription,
                style = MaterialTheme.typography.bodyMedium
            )

            Text(
                text = if (isArabic) "أمر توليد الفيديو (AI Video Prompt):" else "AI Video-Generation Prompt:",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary
            )
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = scene.videoPrompt,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(10.dp)
                )
            }

            if (scene.transition.isNotBlank() || scene.soundEffectNotes.isNotBlank()) {
                Text(
                    text = buildString {
                        if (scene.transition.isNotBlank()) {
                            append(if (isArabic) "الانتقال: ${scene.transition}" else "Transition: ${scene.transition}")
                        }
                        if (scene.soundEffectNotes.isNotBlank()) {
                            if (isNotEmpty()) append(" • ")
                            append(if (isArabic) "مؤثرات: ${scene.soundEffectNotes}" else "SFX: ${scene.soundEffectNotes}")
                        }
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCopyPrompt,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isArabic) "نسخ أمر الفيديو" else "Copy Prompt")
                }
                OutlinedButton(
                    onClick = onCopyVoiceOver,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isArabic) "نسخ التعليق" else "Copy Voice-Over")
                }
            }
        }
    }
}

@Composable
private fun SceneFormDialog(
    initialScene: VideoSceneEntity?,
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String, Int, String, String, String, String) -> Unit
) {
    var voiceOver by remember { mutableStateOf(initialScene?.voiceOverText ?: "") }
    var durationText by remember { mutableStateOf((initialScene?.durationSeconds ?: 8).toString()) }
    var visualDesc by remember { mutableStateOf(initialScene?.visualDescription ?: "") }
    var videoPrompt by remember { mutableStateOf(initialScene?.videoPrompt ?: "") }
    var transition by remember { mutableStateOf(initialScene?.transition ?: "Smooth Cut") }
    var sfxNotes by remember { mutableStateOf(initialScene?.soundEffectNotes ?: "") }
    var errors by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (initialScene == null) {
                    if (isArabic) "إضافة مشهد جديد" else "Add New Scene"
                } else {
                    if (isArabic) "تعديل المشهد #${initialScene.sceneOrder}" else "Edit Scene #${initialScene.sceneOrder}"
                }
            )
        },
        text = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = voiceOver,
                        onValueChange = { voiceOver = it },
                        label = { Text(if (isArabic) "نص التعليق الصوتي *" else "Voice-Over Text *") },
                        isError = errors.containsKey(FormValidator.FIELD_VOICE_OVER),
                        supportingText = { errors[FormValidator.FIELD_VOICE_OVER]?.let { Text(it) } },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = durationText,
                        onValueChange = { durationText = it.filter { ch -> ch.isDigit() } },
                        label = { Text(if (isArabic) "مدة المشهد (بالثواني) *" else "Duration (seconds) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        isError = errors.containsKey(FormValidator.FIELD_SCENE_DURATION),
                        supportingText = { errors[FormValidator.FIELD_SCENE_DURATION]?.let { Text(it) } },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = visualDesc,
                        onValueChange = { visualDesc = it },
                        label = { Text(if (isArabic) "الوصف البصري للمشهد *" else "Visual Description *") },
                        isError = errors.containsKey(FormValidator.FIELD_VISUAL_DESC),
                        supportingText = { errors[FormValidator.FIELD_VISUAL_DESC]?.let { Text(it) } },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = videoPrompt,
                        onValueChange = { videoPrompt = it },
                        label = { Text(if (isArabic) "أمر توليد الفيديو (Prompt) *" else "Video Generation Prompt *") },
                        isError = errors.containsKey(FormValidator.FIELD_VIDEO_PROMPT),
                        supportingText = { errors[FormValidator.FIELD_VIDEO_PROMPT]?.let { Text(it) } },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = transition,
                        onValueChange = { transition = it },
                        label = { Text(if (isArabic) "الانتقال المقترح (اختياري)" else "Transition (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = sfxNotes,
                        onValueChange = { sfxNotes = it },
                        label = { Text(if (isArabic) "ملاحظات المؤثرات الصوتية (اختياري)" else "Sound Effect Notes (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val dur = durationText.toIntOrNull() ?: 0
                    val check = FormValidator.validateSceneForm(
                        voiceOverText = voiceOver,
                        visualDescription = visualDesc,
                        videoPrompt = videoPrompt,
                        durationSeconds = dur,
                        isArabic = isArabic
                    )
                    errors = check.fieldErrors
                    if (check.isValid) {
                        onConfirm(voiceOver, dur, visualDesc, videoPrompt, transition, sfxNotes)
                    }
                }
            ) {
                Text(if (isArabic) "حفظ المشهد" else "Save Scene")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isArabic) "إلغاء" else "Cancel")
            }
        }
    )
}
