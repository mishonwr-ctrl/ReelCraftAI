package com.reelcraft.ai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.reelcraft.ai.ui.screens.AiConfigScreen
import com.reelcraft.ai.ui.screens.CreateProjectScreen
import com.reelcraft.ai.ui.screens.ExportScreen
import com.reelcraft.ai.ui.screens.HomeDashboardScreen
import com.reelcraft.ai.ui.screens.ProjectDetailsScreen
import com.reelcraft.ai.ui.screens.SavedProjectsScreen
import com.reelcraft.ai.ui.screens.SceneEditorScreen
import com.reelcraft.ai.ui.screens.ScriptEditorScreen
import com.reelcraft.ai.ui.screens.SettingsScreen
import com.reelcraft.ai.ui.screens.SplashScreen
import com.reelcraft.ai.ui.viewmodel.ReelCraftViewModel

@Composable
fun ReelCraftNavHost(
    viewModel: ReelCraftViewModel,
    navController: NavHostController = rememberNavController()
) {
    val settings by viewModel.settings.collectAsState()
    val totalProjects by viewModel.totalProjectCount.collectAsState()
    val recentProjects by viewModel.recentProjects.collectAsState()
    val filteredProjects by viewModel.filteredProjects.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategoryFilter.collectAsState()
    val generationState by viewModel.generationState.collectAsState()

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        // A. Splash / Initialization Screen
        composable(Screen.Splash.route) {
            SplashScreen(
                isArabic = settings.isArabic,
                onInitialized = {
                    navController.navigate(Screen.HomeDashboard.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        // B. Home Dashboard
        composable(Screen.HomeDashboard.route) {
            HomeDashboardScreen(
                settings = settings,
                totalProjectsCount = totalProjects,
                recentProjects = recentProjects,
                onCreateNewProject = { templateId ->
                    viewModel.clearGenerationState()
                    navController.navigate(Screen.CreateProject.createRoute(templateId))
                },
                onOpenProjectDetails = { projectId ->
                    navController.navigate(Screen.ProjectDetails.createRoute(projectId))
                },
                onOpenSavedProjects = { initialQuery ->
                    viewModel.updateSearchQuery(initialQuery)
                    navController.navigate(Screen.SavedProjects.route)
                },
                onOpenAiConfig = {
                    navController.navigate(Screen.AiConfig.route)
                },
                onOpenSettings = {
                    navController.navigate(Screen.Settings.route)
                },
                onToggleTheme = {
                    viewModel.toggleQuickTheme()
                }
            )
        }

        // C. New Video Project Form
        composable(
            route = Screen.CreateProject.route,
            arguments = listOf(
                navArgument("templateId") {
                    type = NavType.StringType
                    defaultValue = ""
                }
            )
        ) { backStackEntry ->
            val templateId = backStackEntry.arguments?.getString("templateId").orEmpty()
            CreateProjectScreen(
                initialTemplateId = templateId,
                settings = settings,
                generationState = generationState,
                onGenerateProject = { request, forceDemo ->
                    viewModel.createAndGenerateProject(
                        request = request,
                        forceDemoFallback = forceDemo,
                        onSuccess = { createdProjectId ->
                            navController.navigate(Screen.ProjectDetails.createRoute(createdProjectId)) {
                                popUpTo(Screen.HomeDashboard.route)
                            }
                        }
                    )
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // D. Script Editor
        composable(
            route = Screen.ScriptEditor.route,
            arguments = listOf(navArgument("projectId") { type = NavType.LongType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getLong("projectId") ?: 0L
            val projectWithScenes by viewModel.observeProjectWithScenes(projectId).collectAsState(initial = null)
            ScriptEditorScreen(
                projectWithScenes = projectWithScenes,
                isArabic = settings.isArabic,
                isRegenerating = generationState.isGenerating,
                onSaveScript = { title, hook, script, estDur ->
                    viewModel.saveScriptEdits(
                        projectId = projectId,
                        title = title,
                        openingHook = hook,
                        fullScript = script,
                        estimatedDuration = estDur,
                        onSaved = {}
                    )
                },
                onRegenerateScript = {
                    projectWithScenes?.let { current ->
                        viewModel.regenerateProjectScript(current) { _, _ -> }
                    }
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // E. Scene Editor
        composable(
            route = Screen.SceneEditor.route,
            arguments = listOf(navArgument("projectId") { type = NavType.LongType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getLong("projectId") ?: 0L
            val projectWithScenes by viewModel.observeProjectWithScenes(projectId).collectAsState(initial = null)
            SceneEditorScreen(
                projectWithScenes = projectWithScenes,
                isArabic = settings.isArabic,
                onAddScene = { vo, dur, visual, prompt, transition, sfx ->
                    viewModel.addScene(projectId, vo, dur, visual, prompt, transition, sfx)
                },
                onUpdateScene = { scene -> viewModel.updateScene(scene) },
                onDeleteScene = { sceneId -> viewModel.deleteScene(projectId, sceneId) },
                onReorderScenes = { ordered -> viewModel.reorderScenes(projectId, ordered) },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // F. Saved Projects
        composable(Screen.SavedProjects.route) {
            SavedProjectsScreen(
                projects = filteredProjects,
                searchQuery = searchQuery,
                selectedCategory = selectedCategory,
                isArabic = settings.isArabic,
                onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                onCategoryFilterChange = { viewModel.updateCategoryFilter(it) },
                onOpenProject = { projectId ->
                    navController.navigate(Screen.ProjectDetails.createRoute(projectId))
                },
                onDeleteProject = { projectId ->
                    viewModel.deleteProject(projectId)
                },
                onCreateNewProject = {
                    viewModel.clearGenerationState()
                    navController.navigate(Screen.CreateProject.createRoute(""))
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // G. Project Details
        composable(
            route = Screen.ProjectDetails.route,
            arguments = listOf(navArgument("projectId") { type = NavType.LongType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getLong("projectId") ?: 0L
            val projectWithScenes by viewModel.observeProjectWithScenes(projectId).collectAsState(initial = null)
            ProjectDetailsScreen(
                projectWithScenes = projectWithScenes,
                isArabic = settings.isArabic,
                onOpenScriptEditor = { id ->
                    navController.navigate(Screen.ScriptEditor.createRoute(id))
                },
                onOpenSceneEditor = { id ->
                    navController.navigate(Screen.SceneEditor.createRoute(id))
                },
                onOpenExportScreen = { id ->
                    navController.navigate(Screen.Export.createRoute(id))
                },
                onDeleteProject = { id ->
                    viewModel.deleteProject(id) {
                        navController.popBackStack()
                    }
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // H. Settings
        composable(Screen.Settings.route) {
            SettingsScreen(
                settings = settings,
                totalSavedProjects = totalProjects,
                onSelectLanguage = { viewModel.setLanguage(it) },
                onSelectThemeMode = { viewModel.setThemeMode(it) },
                onUpdateExportPrefs = { segSec, includePrompts ->
                    viewModel.updateExportPreferences(segSec, includePrompts)
                },
                onUpdateSupabaseConfig = { url, anonKey ->
                    viewModel.updateSupabaseConfig(url, anonKey)
                },
                onOpenAiConfig = {
                    navController.navigate(Screen.AiConfig.route)
                },
                onClearAllLocalData = {
                    viewModel.clearAllLocalData {}
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // I. AI Provider Configuration
        composable(Screen.AiConfig.route) {
            AiConfigScreen(
                settings = settings,
                maskedApiKey = viewModel.getStoredApiKeyMasked(),
                onSaveAiConfig = { mode, url, model, key ->
                    viewModel.saveAiConfiguration(mode, url, model, key) {}
                },
                onClearApiKey = { viewModel.clearStoredApiKey() },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // J. Export & Subtitle Preview Screen
        composable(
            route = Screen.Export.route,
            arguments = listOf(navArgument("projectId") { type = NavType.LongType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getLong("projectId") ?: 0L
            val projectWithScenes by viewModel.observeProjectWithScenes(projectId).collectAsState(initial = null)
            ExportScreen(
                projectWithScenes = projectWithScenes,
                settings = settings,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
