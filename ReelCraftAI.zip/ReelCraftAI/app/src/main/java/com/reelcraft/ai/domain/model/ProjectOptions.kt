package com.reelcraft.ai.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class AppLanguage(val code: String, val labelAr: String, val labelEn: String) {
    ARABIC("ar", "العربية (الافتراضية - RTL)", "Arabic (Default - RTL)"),
    ENGLISH("en", "الإنجليزية (LTR)", "English (LTR)");

    fun label(isArabic: Boolean): String = if (isArabic) labelAr else labelEn

    companion object {
        fun fromCode(code: String): AppLanguage =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: ARABIC
    }
}

@Serializable
enum class AppThemeMode(val key: String, val labelAr: String, val labelEn: String) {
    SYSTEM("SYSTEM", "تلقائي (حسب النظام)", "System Default"),
    DARK("DARK", "الوضع الداكن (استوديو)", "Dark Studio"),
    LIGHT("LIGHT", "الوضع الفاتح", "Light Mode");

    fun label(isArabic: Boolean): String = if (isArabic) labelAr else labelEn

    companion object {
        fun fromKey(key: String): AppThemeMode =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: DARK
    }
}

@Serializable
enum class ContentCategory(val key: String, val labelAr: String, val labelEn: String) {
    EDUCATIONAL_FACTS("EDUCATIONAL_FACTS", "حقائق تعليمية", "Educational facts"),
    SHORT_STORIES("SHORT_STORIES", "قصص قصيرة", "Short stories"),
    CHILDRENS_CONTENT("CHILDRENS_CONTENT", "محتوى أطفال", "Children's content"),
    MOTIVATION("MOTIVATION", "تحفيز وتطوير ذات", "Motivation"),
    DOCUMENTARY("DOCUMENTARY", "وثائقي", "Documentary"),
    COMEDY("COMEDY", "كوميديا", "Comedy"),
    CUSTOM("CUSTOM", "مخصص", "Custom");

    fun label(isArabic: Boolean): String = if (isArabic) labelAr else labelEn

    companion object {
        fun fromKey(key: String): ContentCategory =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: EDUCATIONAL_FACTS
    }
}

@Serializable
enum class ScriptLanguage(val key: String, val labelAr: String, val labelEn: String) {
    MSA_ARABIC("MSA_ARABIC", "العربية الفصحى الحديثة", "Modern Standard Arabic"),
    EGYPTIAN_ARABIC("EGYPTIAN_ARABIC", "العامية المصرية", "Egyptian Arabic"),
    ENGLISH("ENGLISH", "الإنجليزية (English)", "English");

    fun label(isArabic: Boolean): String = if (isArabic) labelAr else labelEn

    companion object {
        fun fromKey(key: String): ScriptLanguage =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: MSA_ARABIC
    }
}

@Serializable
enum class TargetPlatform(val key: String, val labelAr: String, val labelEn: String, val aspectRatio: String) {
    TIKTOK("TIKTOK", "تيك توك (TikTok)", "TikTok", "9:16"),
    YOUTUBE_SHORTS("YOUTUBE_SHORTS", "يوتيوب شورتس (Shorts)", "YouTube Shorts", "9:16"),
    INSTAGRAM_REELS("INSTAGRAM_REELS", "إنستغرام ريلز (Reels)", "Instagram Reels", "9:16");

    fun label(isArabic: Boolean): String = if (isArabic) labelAr else labelEn

    companion object {
        fun fromKey(key: String): TargetPlatform =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: TIKTOK
    }
}

@Serializable
enum class TargetDuration(val seconds: Int, val labelAr: String, val labelEn: String) {
    SECONDS_30(30, "٣٠ ثانية (سريع وخاطف)", "30 seconds"),
    SECONDS_60(60, "٦٠ ثانية (قياسي متكامل)", "60 seconds"),
    SECONDS_90(90, "٩٠ ثانية (عميق وتفصيلي)", "90 seconds");

    fun label(isArabic: Boolean): String = if (isArabic) labelAr else labelEn

    companion object {
        fun fromSeconds(seconds: Int): TargetDuration =
            entries.firstOrNull { it.seconds == seconds } ?: SECONDS_60
    }
}

@Serializable
enum class VisualStyle(val key: String, val labelAr: String, val labelEn: String, val promptDescriptor: String) {
    CINEMATIC("CINEMATIC", "سينمائي (Cinematic)", "Cinematic", "Cinematic lighting, anamorphic lens, shallow depth of field, 4K film grain, dramatic color grading, vertical 9:16"),
    REALISTIC("REALISTIC", "واقعي (Realistic)", "Realistic", "Photorealistic, natural lighting, ultra-detailed textures, authentic camera movement, 8k resolution, vertical 9:16"),
    DOCUMENTARY("DOCUMENTARY", "وثائقي (Documentary)", "Documentary", "National Geographic documentary style, handheld realism, archival clarity, expressive environmental framing, vertical 9:16"),
    CARTOON("CARTOON", "كرتوني ثلاثي الأبعاد (Cartoon)", "Cartoon", "Pixar/Disney 3D animated style, vibrant expressive colors, soft global illumination, charming character design, vertical 9:16"),
    COMEDY("COMEDY", "كوميدي مشرق (Comedy)", "Comedy", "Bright high-key studio lighting, expressive comedic timing, dynamic wide-angle framing, crisp vivid colors, vertical 9:16");

    fun label(isArabic: Boolean): String = if (isArabic) labelAr else labelEn

    companion object {
        fun fromKey(key: String): VisualStyle =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: CINEMATIC
    }
}

@Serializable
enum class AiProviderMode(val key: String, val labelAr: String, val labelEn: String) {
    DEMO_LOCAL("DEMO_LOCAL", "الوضع التجريبي المحلّي (بدون إنترنت أو مفتاح)", "Local Demo Mode (No API Key Required)"),
    DIRECT_API("DIRECT_API", "اتصال مباشر بواجهة AI API (للتطوير الشخصي)", "Direct HTTP AI Endpoint (Personal/Dev)"),
    SERVER_PROXY("SERVER_PROXY", "خادم وسيط آمن (Supabase Edge Function - للإنتاج)", "Server-Side Proxy (Production Recommended)");

    fun label(isArabic: Boolean): String = if (isArabic) labelAr else labelEn

    companion object {
        fun fromKey(key: String): AiProviderMode =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: DEMO_LOCAL
    }
}

data class QuickTemplate(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val topicAr: String,
    val topicEn: String,
    val category: ContentCategory,
    val scriptLanguage: ScriptLanguage,
    val platform: TargetPlatform,
    val duration: TargetDuration,
    val visualStyle: VisualStyle,
    val defaultScenes: Int,
    val additionalInstructionsAr: String,
    val additionalInstructionsEn: String
) {
    fun title(isArabic: Boolean): String = if (isArabic) titleAr else titleEn
    fun topic(isArabic: Boolean): String = if (isArabic) topicAr else topicEn
    fun instructions(isArabic: Boolean): String = if (isArabic) additionalInstructionsAr else additionalInstructionsEn
}

object BuiltInTemplates {
    val templates = listOf(
        QuickTemplate(
            id = "space_fact",
            titleAr = "حقيقة علمية مذهلة عن الفضاء",
            titleEn = "Mind-Blowing Space Fact",
            topicAr = "ماذا يحدث لو اقتربت من الثقب الأسود وكيف يتباطأ الزمن حوله؟",
            topicEn = "What happens if you approach a black hole and how time dilation works near the event horizon",
            category = ContentCategory.EDUCATIONAL_FACTS,
            scriptLanguage = ScriptLanguage.MSA_ARABIC,
            platform = TargetPlatform.TIKTOK,
            duration = TargetDuration.SECONDS_60,
            visualStyle = VisualStyle.CINEMATIC,
            defaultScenes = 5,
            additionalInstructionsAr = "ابدأ بسؤال صادم في أول ٣ ثوانٍ واستخدم تشبيهات بصرية بسيطة.",
            additionalInstructionsEn = "Start with a shocking hook in the first 3 seconds and use vivid visual analogies."
        ),
        QuickTemplate(
            id = "cairo_history_doc",
            titleAr = "وثائقي قصير: أسرار التاريخ",
            titleEn = "Mini Documentary: Hidden History",
            topicAr = "كيف بنى المهندسون القدماء مكتبة الإسكندرية وماذا كان بداخلها؟",
            topicEn = "How ancient scholars built the Library of Alexandria and its lost inventions",
            category = ContentCategory.DOCUMENTARY,
            scriptLanguage = ScriptLanguage.EGYPTIAN_ARABIC,
            platform = TargetPlatform.INSTAGRAM_REELS,
            duration = TargetDuration.SECONDS_60,
            visualStyle = VisualStyle.DOCUMENTARY,
            defaultScenes = 5,
            additionalInstructionsAr = "استخدم أسلوب سرد شيّق باللهجة المصرية البسيطة مع وصف بصري تاريخي دقيق.",
            additionalInstructionsEn = "Use engaging storytelling with historically accurate atmospheric visuals."
        ),
        QuickTemplate(
            id = "morning_discipline",
            titleAr = "رسالة تحفيزية: قاعدة الـ ٥ دقائق",
            titleEn = "Motivation: The 5-Minute Focus Rule",
            topicAr = "التغلب على التسويف والبدء في أصعب مهمة يومية خلال خمس دقائق فقط",
            topicEn = "Overcoming procrastination by committing to just 5 focused minutes on your hardest task",
            category = ContentCategory.MOTIVATION,
            scriptLanguage = ScriptLanguage.MSA_ARABIC,
            platform = TargetPlatform.YOUTUBE_SHORTS,
            duration = TargetDuration.SECONDS_30,
            visualStyle = VisualStyle.REALISTIC,
            defaultScenes = 4,
            additionalInstructionsAr = "إيقاع سريع وحماسي مع دعوة واضحة للتطبيق الفوري في نهاية الفيديو.",
            additionalInstructionsEn = "Fast energetic pacing with a clear actionable call-to-action at the end."
        ),
        QuickTemplate(
            id = "kids_bedtime_fable",
            titleAr = "قصة أطفال: السلحفاة الذكية",
            titleEn = "Kids Story: The Clever Little Star",
            topicAr = "نجمة صغيرة تتعلم أن إضاءتها الفريدة تساعد المسافرين في الليل",
            topicEn = "A tiny star learns how its unique glow guides travelers safely through the night",
            category = ContentCategory.CHILDRENS_CONTENT,
            scriptLanguage = ScriptLanguage.MSA_ARABIC,
            platform = TargetPlatform.YOUTUBE_SHORTS,
            duration = TargetDuration.SECONDS_60,
            visualStyle = VisualStyle.CARTOON,
            defaultScenes = 5,
            additionalInstructionsAr = "لغة عربية فصحى سهلة ومحببة للأطفال مع مشاهد كرتونية ملونة ودافئة.",
            additionalInstructionsEn = "Warm, child-friendly narration with colorful 3D animated storybook visuals."
        )
    )
}
