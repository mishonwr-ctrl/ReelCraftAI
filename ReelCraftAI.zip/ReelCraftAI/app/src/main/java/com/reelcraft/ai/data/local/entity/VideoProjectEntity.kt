package com.reelcraft.ai.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "video_projects",
    indices = [
        Index(value = ["updatedAt"]),
        Index(value = ["category"]),
        Index(value = ["title"])
    ]
)
data class VideoProjectEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "title")
    val title: String,

    @ColumnInfo(name = "topic")
    val topic: String,

    @ColumnInfo(name = "category")
    val category: String,

    @ColumnInfo(name = "language")
    val language: String,

    @ColumnInfo(name = "targetPlatform")
    val targetPlatform: String,

    @ColumnInfo(name = "visualStyle")
    val visualStyle: String,

    @ColumnInfo(name = "durationSeconds")
    val durationSeconds: Int,

    @ColumnInfo(name = "openingHook")
    val openingHook: String = "",

    @ColumnInfo(name = "fullScript")
    val fullScript: String,

    @ColumnInfo(name = "additionalInstructions")
    val additionalInstructions: String = "",

    @ColumnInfo(name = "isDemoContent")
    val isDemoContent: Boolean = false,

    @ColumnInfo(name = "createdAt")
    val createdAt: Long,

    @ColumnInfo(name = "updatedAt")
    val updatedAt: Long
)
