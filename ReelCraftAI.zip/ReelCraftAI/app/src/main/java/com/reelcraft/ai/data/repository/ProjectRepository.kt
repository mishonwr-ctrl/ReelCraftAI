package com.reelcraft.ai.data.repository

import com.reelcraft.ai.data.local.dao.ProjectDao
import com.reelcraft.ai.data.local.dao.SceneDao
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import com.reelcraft.ai.domain.model.ProjectWithScenes
import kotlinx.coroutines.flow.Flow

class ProjectRepository(
    private val projectDao: ProjectDao,
    private val sceneDao: SceneDao
) {
    fun observeTotalProjectCount(): Flow<Int> = projectDao.observeTotalProjectCount()

    fun observeRecentProjects(limit: Int = 5): Flow<List<VideoProjectEntity>> =
        projectDao.observeRecentProjects(limit)

    fun observeAllProjects(): Flow<List<VideoProjectEntity>> =
        projectDao.observeAllProjectsSortedByLastModified()

    fun searchProjects(query: String, category: String = ""): Flow<List<VideoProjectEntity>> =
        projectDao.searchProjects(query.trim(), category)

    fun observeProjectWithScenes(projectId: Long): Flow<ProjectWithScenes?> =
        projectDao.observeProjectWithScenes(projectId)

    fun observeScenesForProject(projectId: Long): Flow<List<VideoSceneEntity>> =
        sceneDao.observeScenesForProject(projectId)

    suspend fun getProjectWithScenes(projectId: Long): ProjectWithScenes? =
        projectDao.getProjectWithScenes(projectId)

    suspend fun createProjectWithScenes(
        project: VideoProjectEntity,
        scenes: List<VideoSceneEntity>
    ): Long {
        val now = System.currentTimeMillis()
        val projectId = projectDao.insertProject(
            project.copy(
                id = 0L,
                createdAt = now,
                updatedAt = now
            )
        )
        val normalizedScenes = scenes.mapIndexed { idx, scene ->
            scene.copy(
                id = 0L,
                projectId = projectId,
                sceneOrder = idx + 1
            )
        }
        sceneDao.insertScenes(normalizedScenes)
        return projectId
    }

    suspend fun updateScriptAndMetadata(
        projectId: Long,
        newTitle: String,
        newOpeningHook: String,
        newFullScript: String,
        estimatedDurationSeconds: Int? = null,
        isDemoContent: Boolean? = null
    ) {
        val existing = projectDao.getProjectById(projectId) ?: return
        val now = System.currentTimeMillis()
        projectDao.updateProject(
            existing.copy(
                title = newTitle.trim(),
                openingHook = newOpeningHook.trim(),
                fullScript = newFullScript.trim(),
                durationSeconds = estimatedDurationSeconds ?: existing.durationSeconds,
                isDemoContent = isDemoContent ?: existing.isDemoContent,
                updatedAt = now
            )
        )
    }

    suspend fun replaceScenes(projectId: Long, scenes: List<VideoSceneEntity>) {
        sceneDao.replaceProjectScenes(projectId, scenes)
        projectDao.touchProjectTimestamp(projectId, System.currentTimeMillis())
    }

    suspend fun addScene(projectId: Long, scene: VideoSceneEntity): Long {
        val currentScenes = sceneDao.getScenesForProject(projectId)
        val nextOrder = (currentScenes.maxOfOrNull { it.sceneOrder } ?: 0) + 1
        val insertedId = sceneDao.insertScene(
            scene.copy(
                id = 0L,
                projectId = projectId,
                sceneOrder = nextOrder
            )
        )
        projectDao.touchProjectTimestamp(projectId, System.currentTimeMillis())
        return insertedId
    }

    suspend fun updateScene(scene: VideoSceneEntity) {
        sceneDao.updateScene(scene)
        projectDao.touchProjectTimestamp(scene.projectId, System.currentTimeMillis())
    }

    suspend fun deleteSceneAndReindex(projectId: Long, sceneId: Long) {
        sceneDao.deleteSceneById(sceneId)
        val remaining = sceneDao.getScenesForProject(projectId).sortedBy { it.sceneOrder }
        sceneDao.persistSceneOrdering(remaining)
        projectDao.touchProjectTimestamp(projectId, System.currentTimeMillis())
    }

    suspend fun reorderScenes(projectId: Long, orderedScenes: List<VideoSceneEntity>) {
        sceneDao.persistSceneOrdering(orderedScenes)
        projectDao.touchProjectTimestamp(projectId, System.currentTimeMillis())
    }

    suspend fun deleteProject(projectId: Long) {
        // Foreign key ON DELETE CASCADE automatically deletes associated scenes in video_scenes
        projectDao.deleteProjectById(projectId)
    }

    suspend fun clearAllLocalData() {
        projectDao.deleteAllProjects()
    }
}
