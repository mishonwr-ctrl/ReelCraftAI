package com.reelcraft.ai.ai

import kotlinx.serialization.json.Json

object AiResponseValidator {

    private val lenientJson = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    /**
     * Extracts clean JSON object payload even if the LLM wrapped it in ```json ... ``` markdown fences,
     * parses it into [AiGeneratedProjectDto], and validates all required structural fields.
     */
    fun parseAndValidate(
        rawContent: String,
        fallbackTitle: String,
        targetDurationSeconds: Int
    ): Result<AiGeneratedProjectDto> {
        val trimmed = rawContent.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Empty AI response payload"))
        }

        val jsonText = extractJsonObject(trimmed)
        if (jsonText.isEmpty()) {
            return Result.failure(IllegalArgumentException("No JSON object found in AI response"))
        }

        val parsed = try {
            lenientJson.decodeFromString<AiGeneratedProjectDto>(jsonText)
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException("Malformed JSON syntax: ${e.message}", e))
        }

        if (parsed.scenes.isEmpty()) {
            return Result.failure(IllegalArgumentException("AI response contained zero scenes"))
        }

        val validScenes = parsed.scenes.mapIndexedNotNull { index, scene ->
            val vo = scene.voiceOverText.trim()
            val visual = scene.visualDescription.trim()
            val prompt = scene.videoGenerationPrompt.trim()
            if (vo.isEmpty() && prompt.isEmpty()) {
                null
            } else {
                val defaultDur = (targetDurationSeconds / parsed.scenes.size.coerceAtLeast(1)).coerceIn(3, 30)
                AiGeneratedSceneDto(
                    sceneNumber = index + 1,
                    voiceOverText = vo.ifEmpty { "Scene ${index + 1} narration" },
                    estimatedDurationSeconds = scene.estimatedDurationSeconds.takeIf { it in 2..90 } ?: defaultDur,
                    visualDescription = visual.ifEmpty { prompt },
                    videoGenerationPrompt = prompt.ifEmpty { visual },
                    suggestedTransition = scene.suggestedTransition.trim().ifEmpty { "Smooth Cut" },
                    soundEffectSuggestions = scene.soundEffectSuggestions.trim()
                )
            }
        }

        if (validScenes.isEmpty()) {
            return Result.failure(IllegalArgumentException("All scenes in AI response were missing voice-over and prompts"))
        }

        val resolvedScript = parsed.completeScript.trim().ifEmpty {
            validScenes.joinToString(separator = "\n\n") { it.voiceOverText }
        }

        val resolvedHook = parsed.videoHook.trim().ifEmpty {
            validScenes.first().voiceOverText.lineSequence().firstOrNull()?.take(140).orEmpty()
        }

        val resolvedTitle = parsed.projectTitle.trim().ifEmpty { fallbackTitle.trim() }
        val totalEstimatedDuration = parsed.estimatedDurationSeconds.takeIf { it in 10..300 }
            ?: validScenes.sumOf { it.estimatedDurationSeconds }

        return Result.success(
            AiGeneratedProjectDto(
                projectTitle = resolvedTitle,
                videoHook = resolvedHook,
                completeScript = resolvedScript,
                estimatedDurationSeconds = totalEstimatedDuration,
                scenes = validScenes
            )
        )
    }

    fun extractJsonObject(input: String): String {
        val start = input.indexOf('{')
        val end = input.lastIndexOf('}')
        if (start == -1 || end == -1 || end <= start) {
            return ""
        }
        return input.substring(start, end + 1)
    }
}
