package com.reelcraft.ai.cloud

import com.reelcraft.ai.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.flow.first

sealed class CloudStatus {
    data object NotConfigured : CloudStatus()
    data class ConfiguredReady(val supabaseUrl: String) : CloudStatus()
}

/**
 * Optional Supabase Cloud Integration connector.
 *
 * Security & Honesty Architecture:
 * - Never embeds a Supabase `service_role` secret in the Android client.
 * - Requires user authentication JWT and PostgreSQL Row Level Security (`auth.uid() = user_id`)
 *   so one user's private projects are never exposed to another user.
 * - Keeps the application 100% functional with the local Room database when Supabase is unconfigured.
 */
class SupabaseSyncService(
    private val preferencesRepository: UserPreferencesRepository
) {
    suspend fun getCloudStatus(): CloudStatus {
        val settings = preferencesRepository.settingsFlow.first()
        return if (settings.isSupabaseConfigured) {
            CloudStatus.ConfiguredReady(settings.supabaseUrl)
        } else {
            CloudStatus.NotConfigured
        }
    }
}
