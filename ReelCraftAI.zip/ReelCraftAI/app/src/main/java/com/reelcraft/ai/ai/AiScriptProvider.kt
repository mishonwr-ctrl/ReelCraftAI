package com.reelcraft.ai.ai

import com.reelcraft.ai.domain.model.ContentCategory
import com.reelcraft.ai.domain.model.ScriptLanguage
import com.reelcraft.ai.domain.model.TargetDuration
import com.reelcraft.ai.domain.model.TargetPlatform
import com.reelcraft.ai.domain.model.VisualStyle
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

data class AiGenerationRequest(
    val projectTitle: String,
    val topic: String,
    val category: ContentCategory,
    val scriptLanguage: ScriptLanguage,
    val targetPlatform: TargetPlatform,
    val targetDuration: TargetDuration,
    val visualStyle: VisualStyle,
    val numberOfScenes: Int,
    val additionalInstructions: String = ""
)

@Serializable
data class AiGeneratedSceneDto(
    @SerialName("sceneNumber") val sceneNumber: Int = 1,
    @SerialName("voiceOverText") val voiceOverText: String = "",
    @SerialName("estimatedDurationSeconds") val estimatedDurationSeconds: Int = 8,
    @SerialName("visualDescription") val visualDescription: String = "",
    @SerialName("videoGenerationPrompt") val videoGenerationPrompt: String = "",
    @SerialName("suggestedTransition") val suggestedTransition: String = "",
    @SerialName("soundEffectSuggestions") val soundEffectSuggestions: String = ""
)

@Serializable
data class AiGeneratedProjectDto(
    @SerialName("projectTitle") val projectTitle: String = "",
    @SerialName("videoHook") val videoHook: String = "",
    @SerialName("completeScript") val completeScript: String = "",
    @SerialName("estimatedDurationSeconds") val estimatedDurationSeconds: Int = 60,
    @SerialName("scenes") val scenes: List<AiGeneratedSceneDto> = emptyList()
)

sealed class AiGenerationError(
    val messageAr: String,
    val messageEn: String,
    val cause: Throwable? = null
) {
    fun message(isArabic: Boolean): String = if (isArabic) messageAr else messageEn

    class AuthenticationError(detail: String = "") : AiGenerationError(
        messageAr = "فشل المصادقة (401/403): تأكد من صحة مفتاح API وصلاحياته. $detail".trim(),
        messageEn = "Authentication failed (401/403): Please verify your API key and permissions. $detail".trim()
    )

    class RateLimitError(detail: String = "") : AiGenerationError(
        messageAr = "تم تجاوز الحد المسموح للطلبات (429): يرجى الانتظار قليلاً ثم المحاولة مجدداً. $detail".trim(),
        messageEn = "Rate limit exceeded (429): Please wait a moment and try again. $detail".trim()
    )

    class TimeoutError(cause: Throwable? = null) : AiGenerationError(
        messageAr = "انتهت مهلة الاتصال بالخادم (Timeout): تحقق من جودة الإنترنت أو جرب عدداً أقل من المشاهد.",
        messageEn = "Request timed out: Please check your internet connection or try fewer scenes.",
        cause = cause
    )

    class NetworkError(detail: String = "", cause: Throwable? = null) : AiGenerationError(
        messageAr = "تعذر الاتصال بالشبكة: تحقق من الاتصال بالإنترنت أو صحة رابط نقطة النهاية (Endpoint). $detail".trim(),
        messageEn = "Network connection failed: Check your internet connection or endpoint URL. $detail".trim(),
        cause = cause
    )

    class EmptyResponseError : AiGenerationError(
        messageAr = "أعاد مزود الذكاء الاصطناعي استجابة فارغة.",
        messageEn = "The AI provider returned an empty response."
    )

    class InvalidJsonError(detail: String = "", cause: Throwable? = null) : AiGenerationError(
        messageAr = "تعذر تحليل استجابة JSON من مزود الذكاء الاصطناعي: $detail".trim(),
        messageEn = "Failed to parse structured JSON response from AI provider: $detail".trim(),
        cause = cause
    )

    class ValidationFailedError(detailAr: String, detailEn: String) : AiGenerationError(
        messageAr = detailAr,
        messageEn = detailEn
    )
}

sealed class AiGenerationResult {
    data class Success(
        val data: AiGeneratedProjectDto,
        val isDemoContent: Boolean,
        val providerLabel: String
    ) : AiGenerationResult()

    data class Failure(
        val error: AiGenerationError
    ) : AiGenerationResult()
}

/**
 * Abstraction over AI script and scene generation providers.
 * Allows switching between OpenAI-compatible HTTP endpoints, Supabase Edge Function proxies,
 * or offline Demo Mode without modifying ViewModels or UI screens.
 */
interface AiScriptProvider {
    suspend fun generateProject(request: AiGenerationRequest): AiGenerationResult
}
