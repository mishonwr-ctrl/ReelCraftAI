package com.reelcraft.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.reelcraft.ai.ai.AiGenerationRequest
import com.reelcraft.ai.ai.AiGenerationResult
import com.reelcraft.ai.ai.AiScriptProvider
import com.reelcraft.ai.ai.DemoAiScriptProvider
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import com.reelcraft.ai.data.preferences.StudioSettings
import com.reelcraft.ai.data.preferences.UserPreferencesRepository
import com.reelcraft.ai.data.repository.ProjectRepository
import com.reelcraft.ai.di.AppContainer
import com.reelcraft.ai.domain.model.AiProviderMode
import com.reelcraft.ai.domain.model.AppLanguage
import com.reelcraft.ai.domain.model.AppThemeMode
import com.reelcraft.ai.domain.model.ContentCategory
import com.reelcraft.ai.domain.model.ProjectWithScenes
import com.reelcraft.ai.domain.model.ScriptLanguage
import com.reelcraft.ai.domain.model.TargetDuration
import com.reelcraft.ai.domain.model.TargetPlatform
import com.reelcraft.ai.domain.model.VisualStyle
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GenerationUiState(
    val isGenerating: Boolean = false,
    val errorMessage: String? = null,
    val generatedProjectId: Long? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class ReelCraftViewModel(
    private val projectRepository: ProjectRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val aiScriptProvider: AiScriptProvider,
    private val demoAiProvider: DemoAiScriptProvider
) : ViewModel() {

    val settings: StateFlow<StudioSettings> = preferencesRepository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = StudioSettings()
        )

    val totalProjectCount: StateFlow<Int> = projectRepository.observeTotalProjectCount()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = 0
        )

    val recentProjects: StateFlow<List<VideoProjectEntity>> = projectRepository.observeRecentProjects(limit = 6)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow("")
    val selectedCategoryFilter: StateFlow<String> = _selectedCategoryFilter.asStateFlow()

    val filteredProjects: StateFlow<List<VideoProjectEntity>> = combine(
        _searchQuery,
        _selectedCategoryFilter
    ) { query, cat ->
        query to cat
    }.flatMapLatest { (query, cat) ->
        projectRepository.searchProjects(query = query, category = cat)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    private val _generationState = MutableStateFlow(GenerationUiState())
    val generationState: StateFlow<GenerationUiState> = _generationState.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateCategoryFilter(categoryKey: String) {
        _selectedCategoryFilter.value = categoryKey
    }

    fun observeProjectWithScenes(projectId: Long): Flow<ProjectWithScenes?> {
        return projectRepository.observeProjectWithScenes(projectId)
    }

    fun clearGenerationState() {
        _generationState.value = GenerationUiState()
    }

    fun createAndGenerateProject(
        request: AiGenerationRequest,
        forceDemoFallback: Boolean = false,
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            _generationState.value = GenerationUiState(isGenerating = true, errorMessage = null)
            val isArabic = settings.value.isArabic

            val result = if (forceDemoFallback) {
                demoAiProvider.generateProject(request)
            } else {
                aiScriptProvider.generateProject(request)
            }

            when (result) {
                is AiGenerationResult.Success -> {
                    val dto = result.data
                    val now = System.currentTimeMillis()
                    val projectEntity = VideoProjectEntity(
                        title = dto.projectTitle.ifBlank { request.projectTitle },
                        topic = request.topic.trim(),
                        category = request.category.key,
                        language = request.scriptLanguage.key,
                        targetPlatform = request.targetPlatform.key,
                        visualStyle = request.visualStyle.key,
                        durationSeconds = dto.estimatedDurationSeconds,
                        openingHook = dto.videoHook,
                        fullScript = dto.completeScript,
                        additionalInstructions = request.additionalInstructions.trim(),
                        isDemoContent = result.isDemoContent,
                        createdAt = now,
                        updatedAt = now
                    )
                    val sceneEntities = dto.scenes.mapIndexed { idx, s ->
                        VideoSceneEntity(
                            projectId = 0L,
                            sceneOrder = idx + 1,
                            voiceOverText = s.voiceOverText,
                            durationSeconds = s.estimatedDurationSeconds,
                            visualDescription = s.visualDescription,
                            videoPrompt = s.videoGenerationPrompt,
                            transition = s.suggestedTransition,
                            soundEffectNotes = s.soundEffectSuggestions
                        )
                    }
                    val newId = projectRepository.createProjectWithScenes(projectEntity, sceneEntities)
                    _generationState.value = GenerationUiState(
                        isGenerating = false,
                        generatedProjectId = newId
                    )
                    onSuccess(newId)
                }
                is AiGenerationResult.Failure -> {
                    _generationState.value = GenerationUiState(
                        isGenerating = false,
                        errorMessage = result.error.message(isArabic)
                    )
                }
            }
        }
    }

    fun regenerateProjectScript(
        projectWithScenes: ProjectWithScenes,
        onComplete: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            _generationState.value = GenerationUiState(isGenerating = true)
            val p = projectWithScenes.project
            val isArabic = settings.value.isArabic
            val request = AiGenerationRequest(
                projectTitle = p.title,
                topic = p.topic,
                category = ContentCategory.fromKey(p.category),
                scriptLanguage = ScriptLanguage.fromKey(p.language),
                targetPlatform = TargetPlatform.fromKey(p.targetPlatform),
                targetDuration = TargetDuration.fromSeconds(p.durationSeconds),
                visualStyle = VisualStyle.fromKey(p.visualStyle),
                numberOfScenes = projectWithScenes.scenes.size.coerceIn(3, 12),
                additionalInstructions = p.additionalInstructions
            )

            when (val result = aiScriptProvider.generateProject(request)) {
                is AiGenerationResult.Success -> {
                    val dto = result.data
                    projectRepository.updateScriptAndMetadata(
                        projectId = p.id,
                        newTitle = dto.projectTitle.ifBlank { p.title },
                        newOpeningHook = dto.videoHook,
                        newFullScript = dto.completeScript,
                        estimatedDurationSeconds = dto.estimatedDurationSeconds,
                        isDemoContent = result.isDemoContent
                    )
                    val updatedScenes = dto.scenes.mapIndexed { idx, s ->
                        VideoSceneEntity(
                            projectId = p.id,
                            sceneOrder = idx + 1,
                            voiceOverText = s.voiceOverText,
                            durationSeconds = s.estimatedDurationSeconds,
                            visualDescription = s.visualDescription,
                            videoPrompt = s.videoGenerationPrompt,
                            transition = s.suggestedTransition,
                            soundEffectNotes = s.soundEffectSuggestions
                        )
                    }
                    projectRepository.replaceScenes(p.id, updatedScenes)
                    _generationState.value = GenerationUiState(isGenerating = false)
                    onComplete(true, null)
                }
                is AiGenerationResult.Failure -> {
                    val msg = result.error.message(isArabic)
                    _generationState.value = GenerationUiState(isGenerating = false, errorMessage = msg)
                    onComplete(false, msg)
                }
            }
        }
    }

    fun saveScriptEdits(
        projectId: Long,
        title: String,
        openingHook: String,
        fullScript: String,
        estimatedDuration: Int,
        onSaved: () -> Unit
    ) {
        viewModelScope.launch {
            projectRepository.updateScriptAndMetadata(
                projectId = projectId,
                newTitle = title,
                newOpeningHook = openingHook,
                newFullScript = fullScript,
                estimatedDurationSeconds = estimatedDuration
            )
            onSaved()
        }
    }

    fun addScene(
        projectId: Long,
        voiceOverText: String,
        durationSeconds: Int,
        visualDescription: String,
        videoPrompt: String,
        transition: String,
        soundEffectNotes: String
    ) {
        viewModelScope.launch {
            projectRepository.addScene(
                projectId = projectId,
                scene = VideoSceneEntity(
                    projectId = projectId,
                    sceneOrder = 1,
                    voiceOverText = voiceOverText.trim(),
                    durationSeconds = durationSeconds.coerceIn(1, 120),
                    visualDescription = visualDescription.trim(),
                    videoPrompt = videoPrompt.trim(),
                    transition = transition.trim(),
                    soundEffectNotes = soundEffectNotes.trim()
                )
            )
        }
    }

    fun updateScene(scene: VideoSceneEntity) {
        viewModelScope.launch {
            projectRepository.updateScene(scene)
        }
    }

    fun deleteScene(projectId: Long, sceneId: Long) {
        viewModelScope.launch {
            projectRepository.deleteSceneAndReindex(projectId, sceneId)
        }
    }

    fun reorderScenes(projectId: Long, orderedScenes: List<VideoSceneEntity>) {
        viewModelScope.launch {
            projectRepository.reorderScenes(projectId, orderedScenes)
        }
    }

    fun deleteProject(projectId: Long, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            projectRepository.deleteProject(projectId)
            onDeleted()
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            preferencesRepository.setLanguage(language)
        }
    }

    fun setThemeMode(themeMode: AppThemeMode) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(themeMode)
        }
    }

    fun toggleQuickTheme() {
        val current = settings.value.themeMode
        val next = if (current == AppThemeMode.LIGHT) AppThemeMode.DARK else AppThemeMode.LIGHT
        setThemeMode(next)
    }

    fun saveAiConfiguration(
        mode: AiProviderMode,
        endpointUrl: String,
        modelName: String,
        apiKey: String?,
        onSaved: () -> Unit
    ) {
        viewModelScope.launch {
            preferencesRepository.updateAiConfiguration(
                mode = mode,
                endpointUrl = endpointUrl,
                modelName = modelName,
                apiKey = apiKey
            )
            onSaved()
        }
    }

    fun clearStoredApiKey() {
        viewModelScope.launch {
            preferencesRepository.clearStoredApiKey()
        }
    }

    fun getStoredApiKeyMasked(): String {
        val raw = preferencesRepository.getStoredApiKey()
        if (raw.length <= 6) return ""
        return raw.take(3) + "••••••••" + raw.takeLast(3)
    }

    fun updateExportPreferences(srtSegmentSeconds: Int, includePromptsInTxt: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateExportPreferences(srtSegmentSeconds, includePromptsInTxt)
        }
    }

    fun updateSupabaseConfig(url: String, anonKey: String, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            preferencesRepository.updateSupabaseConfig(url, anonKey)
            onSaved()
        }
    }

    fun clearAllLocalData(onCleared: () -> Unit) {
        viewModelScope.launch {
            projectRepository.clearAllLocalData()
            onCleared()
        }
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ReelCraftViewModel(
                        projectRepository = container.projectRepository,
                        preferencesRepository = container.preferencesRepository,
                        aiScriptProvider = container.aiScriptProvider,
                        demoAiProvider = container.demoAiProvider
                    ) as T
                }
            }
    }
}
