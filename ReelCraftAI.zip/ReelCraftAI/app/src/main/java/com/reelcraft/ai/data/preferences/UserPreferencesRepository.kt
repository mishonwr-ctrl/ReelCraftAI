package com.reelcraft.ai.data.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.reelcraft.ai.BuildConfig
import com.reelcraft.ai.domain.model.AiProviderMode
import com.reelcraft.ai.domain.model.AppLanguage
import com.reelcraft.ai.domain.model.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "reelcraft_settings")

data class StudioSettings(
    val language: AppLanguage = AppLanguage.ARABIC,
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val aiProviderMode: AiProviderMode = AiProviderMode.DEMO_LOCAL,
    val aiEndpointUrl: String = "https://api.openai.com/v1/",
    val aiModelName: String = "gpt-4o-mini",
    val apiKeyConfigured: Boolean = false,
    val defaultSrtSegmentSeconds: Int = 4,
    val includePromptsInTxtExport: Boolean = true,
    val supabaseUrl: String = BuildConfig.DEFAULT_SUPABASE_URL,
    val supabaseAnonKey: String = BuildConfig.DEFAULT_SUPABASE_ANON_KEY
) {
    val isArabic: Boolean
        get() = language == AppLanguage.ARABIC

    val isLiveAiReady: Boolean
        get() = when (aiProviderMode) {
            AiProviderMode.DEMO_LOCAL -> false
            AiProviderMode.DIRECT_API -> aiEndpointUrl.isNotBlank() && apiKeyConfigured
            AiProviderMode.SERVER_PROXY -> aiEndpointUrl.isNotBlank()
        }

    val isSupabaseConfigured: Boolean
        get() = supabaseUrl.startsWith("https://") && supabaseAnonKey.length > 20
}

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("app_language")
        val THEME_MODE = stringPreferencesKey("app_theme_mode")
        val AI_PROVIDER_MODE = stringPreferencesKey("ai_provider_mode")
        val AI_ENDPOINT_URL = stringPreferencesKey("ai_endpoint_url")
        val AI_MODEL_NAME = stringPreferencesKey("ai_model_name")
        val SRT_SEGMENT_SECONDS = intPreferencesKey("srt_segment_seconds")
        val INCLUDE_PROMPTS_IN_TXT = booleanPreferencesKey("include_prompts_in_txt")
        val SUPABASE_URL = stringPreferencesKey("supabase_url")
        val SUPABASE_ANON_KEY = stringPreferencesKey("supabase_anon_key")
    }

    private val encryptedPrefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "reelcraft_secure_credentials",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            // Fallback to private mode preferences on emulators without hardware keystore
            context.getSharedPreferences("reelcraft_credentials_fallback", Context.MODE_PRIVATE)
        }
    }

    private val apiKeyFlow = MutableStateFlow(getStoredApiKey().isNotBlank())

    val settingsFlow: Flow<StudioSettings> = combine(
        context.dataStore.data,
        apiKeyFlow
    ) { prefs, hasKey ->
        StudioSettings(
            language = AppLanguage.fromCode(prefs[Keys.LANGUAGE] ?: AppLanguage.ARABIC.code),
            themeMode = AppThemeMode.fromKey(prefs[Keys.THEME_MODE] ?: AppThemeMode.DARK.key),
            aiProviderMode = AiProviderMode.fromKey(prefs[Keys.AI_PROVIDER_MODE] ?: AiProviderMode.DEMO_LOCAL.key),
            aiEndpointUrl = prefs[Keys.AI_ENDPOINT_URL] ?: "https://api.openai.com/v1/",
            aiModelName = prefs[Keys.AI_MODEL_NAME] ?: "gpt-4o-mini",
            apiKeyConfigured = hasKey,
            defaultSrtSegmentSeconds = (prefs[Keys.SRT_SEGMENT_SECONDS] ?: 4).coerceIn(2, 10),
            includePromptsInTxtExport = prefs[Keys.INCLUDE_PROMPTS_IN_TXT] ?: true,
            supabaseUrl = prefs[Keys.SUPABASE_URL] ?: BuildConfig.DEFAULT_SUPABASE_URL,
            supabaseAnonKey = prefs[Keys.SUPABASE_ANON_KEY] ?: BuildConfig.DEFAULT_SUPABASE_ANON_KEY
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setThemeMode(themeMode: AppThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = themeMode.key }
    }

    suspend fun updateAiConfiguration(
        mode: AiProviderMode,
        endpointUrl: String,
        modelName: String,
        apiKey: String?
    ) {
        context.dataStore.edit { prefs ->
            prefs[Keys.AI_PROVIDER_MODE] = mode.key
            prefs[Keys.AI_ENDPOINT_URL] = endpointUrl.trim()
            prefs[Keys.AI_MODEL_NAME] = modelName.trim().ifBlank { "gpt-4o-mini" }
        }
        if (apiKey != null) {
            encryptedPrefs.edit().putString(SECURE_KEY_AI_TOKEN, apiKey.trim()).apply()
            apiKeyFlow.value = apiKey.trim().isNotBlank()
        }
    }

    suspend fun clearStoredApiKey() {
        encryptedPrefs.edit().remove(SECURE_KEY_AI_TOKEN).apply()
        apiKeyFlow.value = false
    }

    fun getStoredApiKey(): String {
        return encryptedPrefs.getString(SECURE_KEY_AI_TOKEN, "")?.trim().orEmpty()
    }

    suspend fun updateExportPreferences(
        srtSegmentSeconds: Int,
        includePromptsInTxt: Boolean
    ) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SRT_SEGMENT_SECONDS] = srtSegmentSeconds.coerceIn(2, 10)
            prefs[Keys.INCLUDE_PROMPTS_IN_TXT] = includePromptsInTxt
        }
    }

    suspend fun updateSupabaseConfig(url: String, anonKey: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SUPABASE_URL] = url.trim()
            prefs[Keys.SUPABASE_ANON_KEY] = anonKey.trim()
        }
    }

    companion object {
        private const val SECURE_KEY_AI_TOKEN = "secure_ai_api_token"
    }
}
