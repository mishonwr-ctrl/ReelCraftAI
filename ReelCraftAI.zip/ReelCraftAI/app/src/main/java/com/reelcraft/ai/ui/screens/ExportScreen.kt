package com.reelcraft.ai.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VideoSettings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.data.preferences.StudioSettings
import com.reelcraft.ai.domain.model.ProjectWithScenes
import com.reelcraft.ai.util.ProjectExporter
import com.reelcraft.ai.util.SrtSubtitleGenerator
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScreen(
    projectWithScenes: ProjectWithScenes?,
    settings: StudioSettings,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isArabic = settings.isArabic
    val project = projectWithScenes?.project
    val scenes = projectWithScenes?.orderedScenes.orEmpty()

    var segmentDurationSec by rememberSaveable(settings.defaultSrtSegmentSeconds) {
        mutableIntStateOf(settings.defaultSrtSegmentSeconds)
    }

    val srtContent = remember(scenes, segmentDurationSec) {
        SrtSubtitleGenerator.generateSrt(
            scenes = scenes,
            maxSegmentDurationSeconds = segmentDurationSec
        )
    }

    val safeBaseName = (project?.title ?: "reelcraft_project")
        .replace(Regex("[^a-zA-Z0-9_\\-\\u0600-\\u06FF]"), "_")
        .ifBlank { "reelcraft_project" }

    fun notifyWriteResult(result: Result<Unit>) {
        Toast.makeText(
            context,
            if (result.isSuccess) {
                if (isArabic) "تم حفظ الملف بنجاح (UTF-8)" else "File exported successfully (UTF-8)"
            } else {
                val err = result.exceptionOrNull()?.localizedMessage ?: ""
                if (isArabic) "تعذر حفظ الملف: $err" else "Export failed: $err"
            },
            Toast.LENGTH_SHORT
        ).show()
    }

    val exportScriptTxtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && projectWithScenes != null) {
            val content = ProjectExporter.formatScriptAsTxt(
                projectWithScenes = projectWithScenes,
                includeSceneBreakdown = settings.includePromptsInTxtExport
            )
            notifyWriteResult(ProjectExporter.writeUtf8ToUri(context, uri, content))
        }
    }

    val exportSrtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri ->
        if (uri != null) {
            notifyWriteResult(ProjectExporter.writeUtf8ToUri(context, uri, srtContent))
        }
    }

    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null && projectWithScenes != null) {
            val content = ProjectExporter.formatProjectAsJson(projectWithScenes)
            notifyWriteResult(ProjectExporter.writeUtf8ToUri(context, uri, content))
        }
    }

    val exportPromptsTxtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && projectWithScenes != null) {
            val content = ProjectExporter.formatScenePromptsAsTxt(projectWithScenes)
            notifyWriteResult(ProjectExporter.writeUtf8ToUri(context, uri, content))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (isArabic) "التصدير وملفات الترجمة (.SRT)" else "Export & Subtitles (.SRT)")
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isArabic) "رجوع" else "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        if (projectWithScenes == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp)
            ) {
                Text(if (isArabic) "جارٍ تحميل المشروع…" else "Loading project…")
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Export Formats Card (SAF CreateDocument + Quick Share)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "تصدير ملفات المشروع (UTF-8)" else "Export Project Deliverables (UTF-8)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Button(
                            onClick = { exportScriptTxtLauncher.launch("${safeBaseName}_script.txt") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Description, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isArabic) "تصدير السيناريو كملف نصي (.TXT)" else "Export Script as Text (.TXT)")
                        }

                        Button(
                            onClick = { exportSrtLauncher.launch("${safeBaseName}_subtitles.srt") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Subtitles, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isArabic) "تصدير ملف الترجمة (.SRT)" else "Export Subtitles (.SRT)")
                        }

                        Button(
                            onClick = { exportJsonLauncher.launch("${safeBaseName}_project.json") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Code, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isArabic) "تصدير المشروع بالكامل (.JSON)" else "Export Complete Project (.JSON)")
                        }

                        Button(
                            onClick = { exportPromptsTxtLauncher.launch("${safeBaseName}_video_prompts.txt") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.VideoSettings, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isArabic) "تصدير أوامر توليد الفيديو للمشاهد (.TXT)" else "Export Individual Scene Prompts (.TXT)")
                        }

                        OutlinedButton(
                            onClick = {
                                val jsonText = ProjectExporter.formatProjectAsJson(projectWithScenes)
                                ProjectExporter.shareTextFile(
                                    context = context,
                                    fileName = "${safeBaseName}_project.json",
                                    mimeType = "application/json",
                                    content = jsonText
                                ).onSuccess { chooser ->
                                    context.startActivity(chooser)
                                }.onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "Share failed", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isArabic) "مشاركة ملف المشروع عبر التطبيقات" else "Share Project File")
                        }
                    }
                }
            }

            // 2. SRT Timing Configuration & Disclaimer
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (isArabic) "إعدادات تقسيم ملف الترجمة (.SRT)" else "SRT Subtitle Timing Configuration",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) {
                                "الحد الأقصى لمدة المقطع الواحد: $segmentDurationSec ثوانٍ"
                            } else {
                                "Max duration per subtitle cue: ${segmentDurationSec}s"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Slider(
                            value = segmentDurationSec.toFloat(),
                            onValueChange = { segmentDurationSec = it.roundToInt().coerceIn(2, 10) },
                            valueRange = 2f..10f,
                            steps = 7
                        )
                        Text(
                            text = if (isArabic) {
                                "تنبيه هام: التوقيتات الزمنية المقدرة لملفات الترجمة (SRT) هي توقيتات تقريبية محسوبة تلقائياً بناءً على طول النص ومدة كل مشهد، ما لم تتم مزامنتها مع تسجيل صوتي فعلي."
                            } else {
                                "Important: Automatically estimated SRT timings are approximate based on text length and scene duration unless synchronized against an actual voice-over audio recording."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            // 3. Live SRT Preview
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isArabic) "معاينة ملف الترجمة (.SRT)" else "Live SRT Subtitle Preview",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "UTF-8",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = srtContent.ifBlank {
                                    if (isArabic) "لا توجد مشاهد تحتوي على تعليق صوتي لتوليد الترجمة." else "No scene voice-over text available."
                                },
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
