package com.reelcraft.ai.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.domain.model.ProjectWithScenes
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: VideoProjectEntity): Long

    @Update
    suspend fun updateProject(project: VideoProjectEntity)

    @Delete
    suspend fun deleteProject(project: VideoProjectEntity)

    @Query("DELETE FROM video_projects WHERE id = :projectId")
    suspend fun deleteProjectById(projectId: Long)

    @Query("DELETE FROM video_projects")
    suspend fun deleteAllProjects()

    @Query("SELECT * FROM video_projects WHERE id = :projectId LIMIT 1")
    suspend fun getProjectById(projectId: Long): VideoProjectEntity?

    @Query("SELECT * FROM video_projects WHERE id = :projectId LIMIT 1")
    fun observeProjectById(projectId: Long): Flow<VideoProjectEntity?>

    @Transaction
    @Query("SELECT * FROM video_projects WHERE id = :projectId LIMIT 1")
    suspend fun getProjectWithScenes(projectId: Long): ProjectWithScenes?

    @Transaction
    @Query("SELECT * FROM video_projects WHERE id = :projectId LIMIT 1")
    fun observeProjectWithScenes(projectId: Long): Flow<ProjectWithScenes?>

    @Query("SELECT * FROM video_projects ORDER BY updatedAt DESC")
    fun observeAllProjectsSortedByLastModified(): Flow<List<VideoProjectEntity>>

    @Query("SELECT * FROM video_projects ORDER BY updatedAt DESC LIMIT :limit")
    fun observeRecentProjects(limit: Int = 5): Flow<List<VideoProjectEntity>>

    @Query("SELECT COUNT(*) FROM video_projects")
    fun observeTotalProjectCount(): Flow<Int>

    @Query(
        """
        SELECT * FROM video_projects
        WHERE (:query = '' OR title LIKE '%' || :query || '%' OR topic LIKE '%' || :query || '%' OR fullScript LIKE '%' || :query || '%')
          AND (:category = '' OR category = :category)
        ORDER BY updatedAt DESC
        """
    )
    fun searchProjects(query: String, category: String = ""): Flow<List<VideoProjectEntity>>

    @Query("UPDATE video_projects SET updatedAt = :timestamp WHERE id = :projectId")
    suspend fun touchProjectTimestamp(projectId: Long, timestamp: Long = System.currentTimeMillis())
}
