package com.reelcraft.ai.di

import android.content.Context
import com.reelcraft.ai.ai.AiScriptProvider
import com.reelcraft.ai.ai.DemoAiScriptProvider
import com.reelcraft.ai.ai.HttpAiScriptProvider
import com.reelcraft.ai.cloud.SupabaseSyncService
import com.reelcraft.ai.data.local.ReelCraftDatabase
import com.reelcraft.ai.data.preferences.UserPreferencesRepository
import com.reelcraft.ai.data.repository.ProjectRepository

class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    val database: ReelCraftDatabase by lazy {
        ReelCraftDatabase.getInstance(appContext)
    }

    val preferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(appContext)
    }

    val projectRepository: ProjectRepository by lazy {
        ProjectRepository(
            projectDao = database.projectDao(),
            sceneDao = database.sceneDao()
        )
    }

    val demoAiProvider: DemoAiScriptProvider by lazy {
        DemoAiScriptProvider()
    }

    val aiScriptProvider: AiScriptProvider by lazy {
        HttpAiScriptProvider(
            preferencesRepository = preferencesRepository,
            demoFallbackProvider = demoAiProvider
        )
    }

    val supabaseSyncService: SupabaseSyncService by lazy {
        SupabaseSyncService(preferencesRepository)
    }
}
