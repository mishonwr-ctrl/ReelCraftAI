package com.reelcraft.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.domain.model.ContentCategory
import com.reelcraft.ai.domain.model.ProjectWithScenes
import com.reelcraft.ai.domain.model.ScriptLanguage
import com.reelcraft.ai.domain.model.TargetPlatform
import com.reelcraft.ai.domain.model.VisualStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailsScreen(
    projectWithScenes: ProjectWithScenes?,
    isArabic: Boolean,
    onOpenScriptEditor: (Long) -> Unit,
    onOpenSceneEditor: (Long) -> Unit,
    onOpenExportScreen: (Long) -> Unit,
    onDeleteProject: (Long) -> Unit,
    onNavigateBack: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }
    val project = projectWithScenes?.project
    val scenes = projectWithScenes?.orderedScenes.orEmpty()

    if (showDeleteDialog && project != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(if (isArabic) "حذف هذا المشروع؟" else "Delete This Project?") },
            text = {
                Text(
                    if (isArabic) {
                        "سيتم حذف المشروع «${project.title}» وجميع مشاهده نهائياً من قاعدة البيانات."
                    } else {
                        "Project '${project.title}' and all associated scenes will be deleted."
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        onDeleteProject(project.id)
                    }
                ) {
                    Text(
                        text = if (isArabic) "حذف نهائي" else "Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(if (isArabic) "إلغاء" else "Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(project?.title ?: if (isArabic) "تفاصيل المشروع" else "Project Details")
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isArabic) "رجوع" else "Back"
                        )
                    }
                },
                actions = {
                    if (project != null) {
                        IconButton(onClick = { showDeleteDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = if (isArabic) "حذف" else "Delete",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        if (project == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp)
            ) {
                Text(if (isArabic) "جارٍ تحميل بيانات المشروع…" else "Loading project details…")
            }
            return@Scaffold
        }

        val categoryLabel = ContentCategory.fromKey(project.category).label(isArabic)
        val langLabel = ScriptLanguage.fromKey(project.language).label(isArabic)
        val platformLabel = TargetPlatform.fromKey(project.targetPlatform).label(isArabic)
        val styleLabel = VisualStyle.fromKey(project.visualStyle).label(isArabic)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Project Metadata Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (project.isDemoContent) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = if (isArabic) {
                                        "محتوى تجريبي محلي (Demo Sample)"
                                    } else {
                                        "Local Demo Sample Content"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = project.title,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = project.topic,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = "$categoryLabel • $langLabel • $platformLabel • $styleLabel • ${project.durationSeconds}s",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // 2. Primary Workspace Actions (Script Editor, Scene Editor, Export & Subtitles)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onOpenScriptEditor(project.id) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(vertical = 14.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Description, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isArabic) "محرر السيناريو" else "Edit Script")
                        }

                        Button(
                            onClick = { onOpenSceneEditor(project.id) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(vertical = 14.dp)
                        ) {
                            Icon(imageVector = Icons.Default.ViewCarousel, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isArabic) "المشاهد (${scenes.size})" else "Scenes (${scenes.size})")
                        }
                    }

                    OutlinedButton(
                        onClick = { onOpenExportScreen(project.id) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(vertical = 14.dp)
                    ) {
                        Icon(imageVector = Icons.Default.IosShare, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (isArabic) {
                                "توليد ملف الترجمة (.SRT) وتصدير المشروع (.TXT / .JSON)"
                            } else {
                                "Generate Subtitles (.SRT) & Export Project (.TXT / .JSON)"
                            }
                        )
                    }
                }
            }

            // 3. Script Preview
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (isArabic) "الخاطفة والسيناريو الكامل" else "Opening Hook & Full Script",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (project.openingHook.isNotBlank()) {
                            Text(
                                text = "⚡ ${project.openingHook}",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = project.fullScript,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }

            // 4. Scenes Quick Breakdown
            item {
                Text(
                    text = if (isArabic) "ملخص المشاهد (${scenes.size})" else "Scene Breakdown (${scenes.size})",
                    style = MaterialTheme.typography.titleLarge
                )
            }

            items(scenes, key = { it.id }) { scene ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (isArabic) {
                                "المشهد #${scene.sceneOrder} (${scene.durationSeconds} ثانية)"
                            } else {
                                "Scene #${scene.sceneOrder} (${scene.durationSeconds}s)"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = scene.voiceOverText,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            text = "Prompt: ${scene.videoPrompt}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
