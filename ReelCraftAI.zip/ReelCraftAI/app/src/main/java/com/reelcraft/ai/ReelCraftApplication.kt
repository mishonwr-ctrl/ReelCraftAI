package com.reelcraft.ai

import android.app.Application
import com.reelcraft.ai.di.AppContainer

class ReelCraftApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
