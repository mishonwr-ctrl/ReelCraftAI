package com.reelcraft.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.domain.model.ContentCategory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedProjectsScreen(
    projects: List<VideoProjectEntity>,
    searchQuery: String,
    selectedCategory: String,
    isArabic: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onCategoryFilterChange: (String) -> Unit,
    onOpenProject: (Long) -> Unit,
    onDeleteProject: (Long) -> Unit,
    onCreateNewProject: () -> Unit,
    onNavigateBack: () -> Unit
) {
    var projectToDelete by remember { mutableStateOf<VideoProjectEntity?>(null) }

    if (projectToDelete != null) {
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            title = {
                Text(if (isArabic) "حذف المشروع؟" else "Delete Project?")
            },
            text = {
                Text(
                    if (isArabic) {
                        "سيتم حذف المشروع «${projectToDelete?.title}» وجميع مشاهده المرتبطة نهائياً."
                    } else {
                        "Project '${projectToDelete?.title}' and all of its scenes will be permanently deleted."
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        projectToDelete?.let { onDeleteProject(it.id) }
                        projectToDelete = null
                    }
                ) {
                    Text(
                        text = if (isArabic) "حذف" else "Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { projectToDelete = null }) {
                    Text(if (isArabic) "إلغاء" else "Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (isArabic) {
                            "المشاريع المحفوظة (${projects.size})"
                        } else {
                            "Saved Projects (${projects.size})"
                        }
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isArabic) "رجوع" else "Back"
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreateNewProject) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null)
                },
                placeholder = {
                    Text(if (isArabic) "ابحث في العناوين أو المواضيع أو النصوص…" else "Search title, topic, or script…")
                }
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedCategory.isEmpty(),
                        onClick = { onCategoryFilterChange("") },
                        label = { Text(if (isArabic) "الكل" else "All") }
                    )
                }
                items(ContentCategory.entries, key = { it.key }) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat.key,
                        onClick = {
                            onCategoryFilterChange(if (selectedCategory == cat.key) "" else cat.key)
                        },
                        label = { Text(cat.label(isArabic)) }
                    )
                }
            }

            if (projects.isEmpty()) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (isArabic) "لا توجد مشاريع مطابقة" else "No matching projects found",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = if (isArabic) {
                                "جرب تغيير كلمات البحث أو أنشئ مشروع فيديو جديداً."
                            } else {
                                "Try adjusting your search filter or create a new video project."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(projects, key = { it.id }) { project ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                ProjectSummaryCard(
                                    project = project,
                                    isArabic = isArabic,
                                    onClick = { onOpenProject(project.id) }
                                )
                            }
                            IconButton(onClick = { projectToDelete = project }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = if (isArabic) "حذف" else "Delete",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
