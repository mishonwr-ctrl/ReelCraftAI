package com.reelcraft.ai.ai

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.reelcraft.ai.data.preferences.UserPreferencesRepository
import com.reelcraft.ai.domain.model.AiProviderMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.HttpException
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

@Serializable
data class ChatCompletionRequestDto(
    @SerialName("model") val model: String,
    @SerialName("messages") val messages: List<ChatMessageDto>,
    @SerialName("temperature") val temperature: Double = 0.7
)

@Serializable
data class ChatMessageDto(
    @SerialName("role") val role: String,
    @SerialName("content") val content: String
)

@Serializable
data class ChatCompletionResponseDto(
    @SerialName("choices") val choices: List<ChatChoiceDto> = emptyList()
)

@Serializable
data class ChatChoiceDto(
    @SerialName("message") val message: ChatMessageDto? = null
)

interface OpenAiCompatibleApiService {
    @POST
    suspend fun createChatCompletion(
        @Url endpointUrl: String,
        @Header("Authorization") authorization: String,
        @Body body: ChatCompletionRequestDto
    ): Response<ChatCompletionResponseDto>
}

class HttpAiScriptProvider(
    private val preferencesRepository: UserPreferencesRepository,
    private val demoFallbackProvider: DemoAiScriptProvider = DemoAiScriptProvider()
) : AiScriptProvider {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
            .build()
    }

    private val apiService: OpenAiCompatibleApiService by lazy {
        val contentType = "application/json".toMediaType()
        Retrofit.Builder()
            .baseUrl("https://api.openai.com/v1/")
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
            .create(OpenAiCompatibleApiService::class.java)
    }

    override suspend fun generateProject(request: AiGenerationRequest): AiGenerationResult =
        withContext(Dispatchers.IO) {
            val settings = preferencesRepository.settingsFlow.first()

            // When Demo Mode is selected, transparently generate rich local demo content
            // and mark it explicitly as demo content so the user is never misled.
            if (settings.aiProviderMode == AiProviderMode.DEMO_LOCAL) {
                return@withContext demoFallbackProvider.generateProject(request)
            }

            val apiKey = preferencesRepository.getStoredApiKey()
            if (settings.aiProviderMode == AiProviderMode.DIRECT_API && apiKey.isBlank()) {
                return@withContext AiGenerationResult.Failure(
                    AiGenerationError.AuthenticationError("API key is empty.")
                )
            }

            val resolvedUrl = resolveEndpointUrl(settings.aiEndpointUrl, settings.aiProviderMode)
            val authHeader = if (apiKey.isNotBlank()) "Bearer $apiKey" else "Bearer anon-proxy"

            val systemPrompt = buildSystemPrompt(request)
            val userPrompt = buildUserPrompt(request)

            val payload = ChatCompletionRequestDto(
                model = settings.aiModelName.ifBlank { "gpt-4o-mini" },
                messages = listOf(
                    ChatMessageDto(role = "system", content = systemPrompt),
                    ChatMessageDto(role = "user", content = userPrompt)
                ),
                temperature = 0.7
            )

            try {
                val response = apiService.createChatCompletion(
                    endpointUrl = resolvedUrl,
                    authorization = authHeader,
                    body = payload
                )

                if (!response.isSuccessful) {
                    val code = response.code()
                    return@withContext when (code) {
                        401, 403 -> AiGenerationResult.Failure(
                            AiGenerationError.AuthenticationError("HTTP $code")
                        )
                        429 -> AiGenerationResult.Failure(
                            AiGenerationError.RateLimitError("HTTP 429")
                        )
                        else -> AiGenerationResult.Failure(
                            AiGenerationError.NetworkError("HTTP $code ${response.message()}")
                        )
                    }
                }

                val body = response.body()
                val rawContent = body?.choices?.firstOrNull()?.message?.content?.trim().orEmpty()
                if (rawContent.isEmpty()) {
                    return@withContext AiGenerationResult.Failure(
                        AiGenerationError.EmptyResponseError()
                    )
                }

                val validated = AiResponseValidator.parseAndValidate(
                    rawContent = rawContent,
                    fallbackTitle = request.projectTitle,
                    targetDurationSeconds = request.targetDuration.seconds
                )

                validated.fold(
                    onSuccess = { dto ->
                        AiGenerationResult.Success(
                            data = dto,
                            isDemoContent = false,
                            providerLabel = "${settings.aiProviderMode.key} (${settings.aiModelName})"
                        )
                    },
                    onFailure = { err ->
                        AiGenerationResult.Failure(
                            AiGenerationError.InvalidJsonError(
                                detail = err.message ?: "Schema validation failed",
                                cause = err
                            )
                        )
                    }
                )
            } catch (e: SocketTimeoutException) {
                AiGenerationResult.Failure(AiGenerationError.TimeoutError(e))
            } catch (e: HttpException) {
                when (e.code()) {
                    401, 403 -> AiGenerationResult.Failure(AiGenerationError.AuthenticationError("HTTP ${e.code()}"))
                    429 -> AiGenerationResult.Failure(AiGenerationError.RateLimitError("HTTP 429"))
                    else -> AiGenerationResult.Failure(AiGenerationError.NetworkError("HTTP ${e.code()}", e))
                }
            } catch (e: IOException) {
                AiGenerationResult.Failure(AiGenerationError.NetworkError(e.localizedMessage ?: "IO Error", e))
            } catch (e: Exception) {
                AiGenerationResult.Failure(AiGenerationError.InvalidJsonError(e.localizedMessage ?: "Unexpected Error", e))
            }
        }

    private fun resolveEndpointUrl(baseUrl: String, mode: AiProviderMode): String {
        val clean = baseUrl.trim()
        if (mode == AiProviderMode.SERVER_PROXY) {
            return clean
        }
        return if (clean.endsWith("/chat/completions")) {
            clean
        } else if (clean.endsWith("/")) {
            "${clean}chat/completions"
        } else {
            "$clean/chat/completions"
        }
    }

    private fun buildSystemPrompt(request: AiGenerationRequest): String {
        return """
            You are an expert short-form video scriptwriter and AI director for ${request.targetPlatform.labelEn} (${request.targetPlatform.aspectRatio}).
            Respond ONLY with a valid JSON object matching this exact schema (no markdown code blocks, no extra prose):
            {
              "projectTitle": "string",
              "videoHook": "string (engaging opening 3-second hook in the requested script language)",
              "completeScript": "string (complete voice-over script in the requested script language)",
              "estimatedDurationSeconds": ${request.targetDuration.seconds},
              "scenes": [
                {
                  "sceneNumber": 1,
                  "voiceOverText": "string (in ${request.scriptLanguage.labelEn})",
                  "estimatedDurationSeconds": 10,
                  "visualDescription": "string (detailed visual storyboard description)",
                  "videoGenerationPrompt": "string (detailed English prompt for AI video generators like Sora, Runway Gen-3, Kling, or Pika in ${request.visualStyle.promptDescriptor})",
                  "suggestedTransition": "string",
                  "soundEffectSuggestions": "string"
                }
              ]
            }
        """.trimIndent()
    }

    private fun buildUserPrompt(request: AiGenerationRequest): String {
        return """
            Create a ${request.targetDuration.seconds}-second short-form video project with exactly ${request.numberOfScenes} scenes.
            - Project Title: ${request.projectTitle}
            - Topic / Core Idea: ${request.topic}
            - Category: ${request.category.labelEn}
            - Script Language: ${request.scriptLanguage.labelEn}
            - Target Platform: ${request.targetPlatform.labelEn}
            - Visual Style: ${request.visualStyle.labelEn} (${request.visualStyle.promptDescriptor})
            - Additional Instructions: ${request.additionalInstructions.ifBlank { "None" }}
        """.trimIndent()
    }
}
