package com.reelcraft.ai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.reelcraft.ai.data.local.dao.ProjectDao
import com.reelcraft.ai.data.local.dao.SceneDao
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.local.entity.VideoSceneEntity

@Database(
    entities = [
        VideoProjectEntity::class,
        VideoSceneEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class ReelCraftDatabase : RoomDatabase() {

    abstract fun projectDao(): ProjectDao
    abstract fun sceneDao(): SceneDao

    companion object {
        private const val DATABASE_NAME = "reelcraft_studio.db"

        @Volatile
        private var INSTANCE: ReelCraftDatabase? = null

        fun getInstance(context: Context): ReelCraftDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ReelCraftDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
