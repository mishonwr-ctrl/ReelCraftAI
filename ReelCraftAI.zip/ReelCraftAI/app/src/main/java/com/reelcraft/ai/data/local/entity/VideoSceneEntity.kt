package com.reelcraft.ai.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "video_scenes",
    foreignKeys = [
        ForeignKey(
            entity = VideoProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE,
            onUpdate = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["projectId"]),
        Index(value = ["projectId", "sceneOrder"])
    ]
)
data class VideoSceneEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "projectId")
    val projectId: Long,

    @ColumnInfo(name = "sceneOrder")
    val sceneOrder: Int,

    @ColumnInfo(name = "voiceOverText")
    val voiceOverText: String,

    @ColumnInfo(name = "durationSeconds")
    val durationSeconds: Int,

    @ColumnInfo(name = "visualDescription")
    val visualDescription: String,

    @ColumnInfo(name = "videoPrompt")
    val videoPrompt: String,

    @ColumnInfo(name = "transition")
    val transition: String = "",

    @ColumnInfo(name = "soundEffectNotes")
    val soundEffectNotes: String = ""
)
