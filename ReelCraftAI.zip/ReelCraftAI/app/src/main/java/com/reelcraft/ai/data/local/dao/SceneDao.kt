package com.reelcraft.ai.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SceneDao {

    @Query("SELECT * FROM video_scenes WHERE projectId = :projectId ORDER BY sceneOrder ASC, id ASC")
    fun observeScenesForProject(projectId: Long): Flow<List<VideoSceneEntity>>

    @Query("SELECT * FROM video_scenes WHERE projectId = :projectId ORDER BY sceneOrder ASC, id ASC")
    suspend fun getScenesForProject(projectId: Long): List<VideoSceneEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScene(scene: VideoSceneEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<VideoSceneEntity>): List<Long>

    @Update
    suspend fun updateScene(scene: VideoSceneEntity)

    @Update
    suspend fun updateScenes(scenes: List<VideoSceneEntity>)

    @Delete
    suspend fun deleteScene(scene: VideoSceneEntity)

    @Query("DELETE FROM video_scenes WHERE id = :sceneId")
    suspend fun deleteSceneById(sceneId: Long)

    @Query("DELETE FROM video_scenes WHERE projectId = :projectId")
    suspend fun deleteScenesForProject(projectId: Long)

    @Query("UPDATE video_scenes SET sceneOrder = :newOrder WHERE id = :sceneId")
    suspend fun updateSceneOrder(sceneId: Long, newOrder: Int)

    @Transaction
    suspend fun replaceProjectScenes(projectId: Long, newScenes: List<VideoSceneEntity>) {
        deleteScenesForProject(projectId)
        val normalized = newScenes.mapIndexed { index, scene ->
            scene.copy(id = 0L, projectId = projectId, sceneOrder = index + 1)
        }
        insertScenes(normalized)
    }

    @Transaction
    suspend fun persistSceneOrdering(orderedScenes: List<VideoSceneEntity>) {
        val reindexed = orderedScenes.mapIndexed { index, scene ->
            scene.copy(sceneOrder = index + 1)
        }
        updateScenes(reindexed)
    }
}
