package com.reelcraft.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.reelcraft.ai.domain.model.AppLanguage
import com.reelcraft.ai.domain.model.AppThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = StudioVioletPrimary,
    onPrimary = Color.White,
    primaryContainer = StudioVioletContainer,
    onPrimaryContainer = StudioTextPrimaryDark,
    secondary = StudioAmberAccent,
    onSecondary = Color.Black,
    tertiary = StudioEmeraldSuccess,
    background = StudioObsidian,
    onBackground = StudioTextPrimaryDark,
    surface = StudioSurfaceDark,
    onSurface = StudioTextPrimaryDark,
    surfaceVariant = StudioCardDark,
    onSurfaceVariant = StudioTextSecondaryDark,
    error = StudioCoralError,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = StudioVioletLightPrimary,
    onPrimary = Color.White,
    primaryContainer = StudioVioletLightContainer,
    onPrimaryContainer = StudioTextPrimaryLight,
    secondary = StudioAmberLightAccent,
    onSecondary = Color.White,
    tertiary = StudioEmeraldSuccess,
    background = StudioIvory,
    onBackground = StudioTextPrimaryLight,
    surface = StudioSurfaceLight,
    onSurface = StudioTextPrimaryLight,
    surfaceVariant = StudioCardLight,
    onSurfaceVariant = StudioTextSecondaryLight,
    error = StudioCoralError,
    onError = Color.White
)

@Composable
fun ReelCraftTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    language: AppLanguage = AppLanguage.ARABIC,
    content: @Composable () -> Unit
) {
    val useDarkTheme = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (useDarkTheme) DarkColorScheme else LightColorScheme
    val layoutDirection = if (language == AppLanguage.ARABIC) {
        LayoutDirection.Rtl
    } else {
        LayoutDirection.Ltr
    }

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = ReelCraftTypography,
            content = content
        )
    }
}
