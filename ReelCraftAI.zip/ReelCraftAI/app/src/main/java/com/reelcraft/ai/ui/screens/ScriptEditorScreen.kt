package com.reelcraft.ai.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.domain.model.ProjectWithScenes
import com.reelcraft.ai.domain.validation.FormValidator
import com.reelcraft.ai.util.ProjectExporter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScriptEditorScreen(
    projectWithScenes: ProjectWithScenes?,
    isArabic: Boolean,
    isRegenerating: Boolean,
    onSaveScript: (String, String, String, Int) -> Unit,
    onRegenerateScript: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val project = projectWithScenes?.project

    var editedTitle by rememberSaveable(project?.id) { mutableStateOf(project?.title ?: "") }
    var editedHook by rememberSaveable(project?.id) { mutableStateOf(project?.openingHook ?: "") }
    var editedScript by rememberSaveable(project?.id) { mutableStateOf(project?.fullScript ?: "") }
    var showUnsavedDialog by remember { mutableStateOf(false) }
    var validationErrors by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    LaunchedEffect(project?.updatedAt) {
        if (project != null) {
            editedTitle = project.title
            editedHook = project.openingHook
            editedScript = project.fullScript
        }
    }

    val hasUnsavedChanges = project != null && (
        editedTitle.trim() != project.title.trim() ||
            editedHook.trim() != project.openingHook.trim() ||
            editedScript.trim() != project.fullScript.trim()
        )

    val estimatedDuration = FormValidator.estimateSpeakingDurationSeconds(editedScript)

    val createTxtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && projectWithScenes != null) {
            val currentSnapshot = projectWithScenes.copy(
                project = projectWithScenes.project.copy(
                    title = editedTitle,
                    openingHook = editedHook,
                    fullScript = editedScript
                )
            )
            val txtContent = ProjectExporter.formatScriptAsTxt(currentSnapshot)
            val res = ProjectExporter.writeUtf8ToUri(context, uri, txtContent)
            Toast.makeText(
                context,
                if (res.isSuccess) {
                    if (isArabic) "تم تصدير السيناريو بنجاح" else "Script exported successfully"
                } else {
                    if (isArabic) "فشل تصدير الملف" else "Export failed"
                },
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun handleBackRequest() {
        if (hasUnsavedChanges) {
            showUnsavedDialog = true
        } else {
            onNavigateBack()
        }
    }

    BackHandler(enabled = true) {
        handleBackRequest()
    }

    if (showUnsavedDialog) {
        AlertDialog(
            onDismissRequest = { showUnsavedDialog = false },
            title = {
                Text(if (isArabic) "تجاهل التعديلات غير المحفوظة؟" else "Discard Unsaved Changes?")
            },
            text = {
                Text(
                    if (isArabic) {
                        "لديك تعديلات غير محفوظة في السيناريو. هل تريد تجاهلها والخروج؟"
                    } else {
                        "You have modified the script without saving. Discard your changes?"
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showUnsavedDialog = false
                        onNavigateBack()
                    }
                ) {
                    Text(
                        text = if (isArabic) "تجاهل التعديلات" else "Discard",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnsavedDialog = false }) {
                    Text(if (isArabic) "متابعة التحرير" else "Keep Editing")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (isArabic) "محرر السيناريو" else "Script Editor")
                },
                navigationIcon = {
                    IconButton(onClick = { handleBackRequest() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isArabic) "رجوع" else "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val combined = buildString {
                                if (editedHook.isNotBlank()) {
                                    appendLine(editedHook.trim())
                                    appendLine()
                                }
                                append(editedScript.trim())
                            }
                            clipboard.setPrimaryClip(ClipData.newPlainText("ReelCraft Script", combined))
                            Toast.makeText(
                                context,
                                if (isArabic) "تم نسخ السيناريو إلى الحافظة" else "Script copied to clipboard",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy")
                    }
                    IconButton(
                        onClick = {
                            val safeName = (editedTitle.ifBlank { "script" })
                                .replace(Regex("[^a-zA-Z0-9_\\-\\u0600-\\u06FF]"), "_")
                            createTxtLauncher.launch("${safeName}_script.txt")
                        }
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = "Export TXT")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (project == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp)
            ) {
                Text(if (isArabic) "جارٍ تحميل المشروع…" else "Loading project…")
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Duration & Mode Info Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (isArabic) {
                                "المدة التقديرية للإلقاء الصوتي: ~$estimatedDuration ثانية (الهدف: ${project.durationSeconds} ثانية)"
                            } else {
                                "Estimated speaking duration: ~${estimatedDuration}s (Target: ${project.durationSeconds}s)"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        if (project.isDemoContent) {
                            Text(
                                text = if (isArabic) {
                                    "تنبيه: هذا النص تم توليده بواسطة الوضع التجريبي المحلّي (محتوى نموذجي)."
                                } else {
                                    "Notice: This script was generated in Local Demo Mode (sample content)."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            // Title Field
            item {
                OutlinedTextField(
                    value = editedTitle,
                    onValueChange = {
                        editedTitle = it
                        validationErrors = validationErrors - FormValidator.FIELD_TITLE
                    },
                    label = { Text(if (isArabic) "عنوان السيناريو *" else "Script Title *") },
                    isError = validationErrors.containsKey(FormValidator.FIELD_TITLE),
                    supportingText = {
                        validationErrors[FormValidator.FIELD_TITLE]?.let { Text(it) }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Opening Hook Field
            item {
                OutlinedTextField(
                    value = editedHook,
                    onValueChange = { editedHook = it },
                    label = {
                        Text(
                            if (isArabic) {
                                "الخاطفة الاستهلالية (Hook - أول ٣ ثوانٍ)"
                            } else {
                                "Opening Hook (First 3 Seconds)"
                            }
                        )
                    },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Complete Script Field
            item {
                OutlinedTextField(
                    value = editedScript,
                    onValueChange = {
                        editedScript = it
                        validationErrors = validationErrors - FormValidator.FIELD_SCRIPT
                    },
                    label = {
                        Text(if (isArabic) "النص الكامل للسيناريو *" else "Complete Narration Script *")
                    },
                    isError = validationErrors.containsKey(FormValidator.FIELD_SCRIPT),
                    supportingText = {
                        validationErrors[FormValidator.FIELD_SCRIPT]?.let { Text(it) }
                    },
                    minLines = 10,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Action Buttons (Save, Regenerate, Export TXT)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            val check = FormValidator.validateScriptEditorForm(
                                title = editedTitle,
                                fullScript = editedScript,
                                isArabic = isArabic
                            )
                            validationErrors = check.fieldErrors
                            if (check.isValid) {
                                onSaveScript(editedTitle, editedHook, editedScript, estimatedDuration)
                                Toast.makeText(
                                    context,
                                    if (isArabic) "تم حفظ التعديلات بنجاح" else "Changes saved",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isArabic) "حفظ التعديلات" else "Save Changes")
                    }

                    OutlinedButton(
                        onClick = onRegenerateScript,
                        enabled = !isRegenerating,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isArabic) "إعادة التوليد" else "Regenerate")
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
