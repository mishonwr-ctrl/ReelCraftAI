package com.reelcraft.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.ai.AiGenerationRequest
import com.reelcraft.ai.data.preferences.StudioSettings
import com.reelcraft.ai.domain.model.BuiltInTemplates
import com.reelcraft.ai.domain.model.ContentCategory
import com.reelcraft.ai.domain.model.ScriptLanguage
import com.reelcraft.ai.domain.model.TargetDuration
import com.reelcraft.ai.domain.model.TargetPlatform
import com.reelcraft.ai.domain.model.VisualStyle
import com.reelcraft.ai.domain.validation.FormValidator
import com.reelcraft.ai.ui.viewmodel.GenerationUiState
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CreateProjectScreen(
    initialTemplateId: String,
    settings: StudioSettings,
    generationState: GenerationUiState,
    onGenerateProject: (AiGenerationRequest, Boolean) -> Unit,
    onNavigateBack: () -> Unit
) {
    val isArabic = settings.isArabic
    val matchedTemplate = remember(initialTemplateId) {
        BuiltInTemplates.templates.firstOrNull { it.id == initialTemplateId }
    }

    var title by rememberSaveable {
        mutableStateOf(matchedTemplate?.title(isArabic) ?: "")
    }
    var topic by rememberSaveable {
        mutableStateOf(matchedTemplate?.topic(isArabic) ?: "")
    }
    var selectedCategory by rememberSaveable {
        mutableStateOf(matchedTemplate?.category ?: ContentCategory.EDUCATIONAL_FACTS)
    }
    var selectedLanguage by rememberSaveable {
        mutableStateOf(matchedTemplate?.scriptLanguage ?: ScriptLanguage.MSA_ARABIC)
    }
    var selectedPlatform by rememberSaveable {
        mutableStateOf(matchedTemplate?.platform ?: TargetPlatform.TIKTOK)
    }
    var selectedDuration by rememberSaveable {
        mutableStateOf(matchedTemplate?.duration ?: TargetDuration.SECONDS_60)
    }
    var selectedStyle by rememberSaveable {
        mutableStateOf(matchedTemplate?.visualStyle ?: VisualStyle.CINEMATIC)
    }
    var sceneCount by rememberSaveable {
        mutableIntStateOf(matchedTemplate?.defaultScenes ?: 5)
    }
    var additionalInstructions by rememberSaveable {
        mutableStateOf(matchedTemplate?.instructions(isArabic) ?: "")
    }

    var fieldErrors by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    fun validateAndSubmit(forceDemo: Boolean) {
        val validation = FormValidator.validateNewProjectForm(
            title = title,
            topic = topic,
            sceneCount = sceneCount,
            durationSeconds = selectedDuration.seconds,
            isArabic = isArabic
        )
        fieldErrors = validation.fieldErrors
        if (!validation.isValid) return

        onGenerateProject(
            AiGenerationRequest(
                projectTitle = title.trim(),
                topic = topic.trim(),
                category = selectedCategory,
                scriptLanguage = selectedLanguage,
                targetPlatform = selectedPlatform,
                targetDuration = selectedDuration,
                visualStyle = selectedStyle,
                numberOfScenes = sceneCount,
                additionalInstructions = additionalInstructions.trim()
            ),
            forceDemo
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (isArabic) "مشروع فيديو جديد" else "New Video Project")
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isArabic) "رجوع" else "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mode Notice Banner
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (settings.isLiveAiReady) {
                                if (isArabic) {
                                    "وضع التوليد: مزود ذكاء اصطناعي حي (${settings.aiModelName})"
                                } else {
                                    "Generation Mode: Live AI Provider (${settings.aiModelName})"
                                }
                            } else {
                                if (isArabic) {
                                    "وضع التوليد الحالي: الوضع التجريبي المحلّي (سيتم إنشاء سيناريو ومشاهد نموذجية مخصصة لموضوعك مع تمييزها كـ «محتوى تجريبي»)."
                                } else {
                                    "Current Mode: Local Demo Mode (Generates structured sample script & scenes tailored to your topic and clearly labeled as Demo)."
                                }
                            },
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // 1. Project Title
            item {
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        fieldErrors = fieldErrors - FormValidator.FIELD_TITLE
                    },
                    label = { Text(if (isArabic) "عنوان المشروع *" else "Project Title *") },
                    isError = fieldErrors.containsKey(FormValidator.FIELD_TITLE),
                    supportingText = {
                        fieldErrors[FormValidator.FIELD_TITLE]?.let { Text(it) }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 2. Video Topic / Idea
            item {
                OutlinedTextField(
                    value = topic,
                    onValueChange = {
                        topic = it
                        fieldErrors = fieldErrors - FormValidator.FIELD_TOPIC
                    },
                    label = {
                        Text(if (isArabic) "موضوع الفيديو أو الفكرة الأساسية *" else "Video Topic or Initial Idea *")
                    },
                    isError = fieldErrors.containsKey(FormValidator.FIELD_TOPIC),
                    supportingText = {
                        fieldErrors[FormValidator.FIELD_TOPIC]?.let { Text(it) }
                    },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 3. Content Category
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isArabic) "تصنيف المحتوى" else "Content Category",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ContentCategory.entries.forEach { category ->
                            FilterChip(
                                selected = selectedCategory == category,
                                onClick = { selectedCategory = category },
                                label = { Text(category.label(isArabic)) }
                            )
                        }
                    }
                }
            }

            // 4. Script Language
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isArabic) "لغة السيناريو" else "Script Language",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ScriptLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = selectedLanguage == lang,
                                onClick = { selectedLanguage = lang },
                                label = { Text(lang.label(isArabic)) }
                            )
                        }
                    }
                }
            }

            // 5. Target Platform
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isArabic) "المنصة المستهدفة" else "Target Platform",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TargetPlatform.entries.forEach { platform ->
                            FilterChip(
                                selected = selectedPlatform == platform,
                                onClick = { selectedPlatform = platform },
                                label = { Text(platform.label(isArabic)) }
                            )
                        }
                    }
                }
            }

            // 6. Target Duration
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isArabic) "المدة المستهدفة" else "Target Duration",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TargetDuration.entries.forEach { dur ->
                            FilterChip(
                                selected = selectedDuration == dur,
                                onClick = { selectedDuration = dur },
                                label = { Text(dur.label(isArabic)) }
                            )
                        }
                    }
                }
            }

            // 7. Visual Style
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isArabic) "النمط البصري (Visual Style)" else "Visual Style",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VisualStyle.entries.forEach { style ->
                            FilterChip(
                                selected = selectedStyle == style,
                                onClick = { selectedStyle = style },
                                label = { Text(style.label(isArabic)) }
                            )
                        }
                    }
                }
            }

            // 8. Number of Scenes
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isArabic) "عدد المشاهد" else "Number of Scenes",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isArabic) "$sceneCount مشاهد" else "$sceneCount scenes",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = sceneCount.toFloat(),
                        onValueChange = { sceneCount = it.roundToInt().coerceIn(2, 12) },
                        valueRange = 2f..12f,
                        steps = 9
                    )
                }
            }

            // 9. Optional Additional Instructions
            item {
                OutlinedTextField(
                    value = additionalInstructions,
                    onValueChange = { additionalInstructions = it },
                    label = {
                        Text(if (isArabic) "تعليمات إضافية (اختياري)" else "Additional Instructions (Optional)")
                    },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Error display from AI service if any
            if (generationState.errorMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = generationState.errorMessage,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            OutlinedButton(
                                onClick = { validateAndSubmit(forceDemo = true) }
                            ) {
                                Text(
                                    if (isArabic) {
                                        "المتابعة باستخدام الوضع التجريبي المحلّي"
                                    } else {
                                        "Proceed with Local Demo Mode Instead"
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Submit Button
            item {
                Button(
                    onClick = { validateAndSubmit(forceDemo = false) },
                    enabled = !generationState.isGenerating,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    if (generationState.isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(if (isArabic) "جارٍ توليد السيناريو والمشاهد…" else "Generating Script & Scenes…")
                    } else {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "توليد السيناريو والمشاهد" else "Generate Script & Scenes",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
