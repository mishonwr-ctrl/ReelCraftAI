package com.reelcraft.ai.domain.model

import androidx.room.Embedded
import androidx.room.Relation
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import kotlinx.serialization.Serializable

@Serializable
data class ProjectWithScenes(
    @Embedded
    val project: VideoProjectEntity,

    @Relation(
        parentColumn = "id",
        entityColumn = "projectId"
    )
    val scenes: List<VideoSceneEntity> = emptyList()
) {
    val orderedScenes: List<VideoSceneEntity>
        get() = scenes.sortedBy { it.sceneOrder }

    val totalScenesDurationSeconds: Int
        get() = scenes.sumOf { it.durationSeconds.coerceAtLeast(1) }
}
