package com.reelcraft.ai.util

import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import java.util.Locale

data class SubtitleSegment(
    val index: Int,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val text: String
)

object SrtSubtitleGenerator {

    /**
     * Generates a standard SubRip (.srt) UTF-8 subtitle string from ordered project scenes.
     *
     * Requirements satisfied:
     * - Sequential 1-based SRT numbering
     * - Valid timestamp formatting `HH:MM:SS,mmm --> HH:MM:SS,mmm`
     * - Configurable maximum duration per subtitle segment (`maxSegmentDurationSeconds`)
     * - Intelligent segmentation into readable subtitle lines (handles Arabic RTL and English text)
     */
    fun generateSrt(
        scenes: List<VideoSceneEntity>,
        maxSegmentDurationSeconds: Int = 4,
        maxCharsPerLine: Int = 42,
        maxLinesPerCue: Int = 2
    ): String {
        val segments = buildSubtitleSegments(
            scenes = scenes,
            maxSegmentDurationSeconds = maxSegmentDurationSeconds.coerceIn(1, 15),
            maxCharsPerLine = maxCharsPerLine.coerceIn(20, 80),
            maxLinesPerCue = maxLinesPerCue.coerceIn(1, 3)
        )
        if (segments.isEmpty()) return ""

        val sb = StringBuilder()
        segments.forEachIndexed { idx, segment ->
            sb.append(segment.index).append("\n")
            sb.append(formatTimestamp(segment.startTimeMs))
                .append(" --> ")
                .append(formatTimestamp(segment.endTimeMs))
                .append("\n")
            sb.append(segment.text).append("\n")
            if (idx < segments.lastIndex) {
                sb.append("\n")
            }
        }
        return sb.toString()
    }

    fun buildSubtitleSegments(
        scenes: List<VideoSceneEntity>,
        maxSegmentDurationSeconds: Int = 4,
        maxCharsPerLine: Int = 42,
        maxLinesPerCue: Int = 2
    ): List<SubtitleSegment> {
        val orderedScenes = scenes.sortedBy { it.sceneOrder }
        val result = mutableListOf<SubtitleSegment>()
        var currentTimeMs = 0L
        var cueCounter = 1
        val safeMaxSegmentMs = (maxSegmentDurationSeconds.coerceAtLeast(1)) * 1000L

        for (scene in orderedScenes) {
            val rawText = scene.voiceOverText.trim()
            val sceneDurationMs = (scene.durationSeconds.coerceAtLeast(1)) * 1000L

            if (rawText.isEmpty()) {
                currentTimeMs += sceneDurationMs
                continue
            }

            // Determine how many cues this scene needs based on both duration and text length
            val words = rawText.split(Regex("\\s+")).filter { it.isNotBlank() }
            val maxCharsPerCue = maxCharsPerLine * maxLinesPerCue
            val cuesByDuration = ((sceneDurationMs + safeMaxSegmentMs - 1) / safeMaxSegmentMs).toInt().coerceAtLeast(1)
            val cuesByLength = ((rawText.length + maxCharsPerCue - 1) / maxCharsPerCue).coerceAtLeast(1)
            val cueCount = maxOf(cuesByDuration, cuesByLength).coerceAtMost(words.size.coerceAtLeast(1))

            val wordChunks = splitWordsEvenly(words, cueCount)
            val totalWordsInScene = words.size.coerceAtLeast(1)
            var sceneElapsedMs = 0L

            wordChunks.forEachIndexed { chunkIdx, chunkWords ->
                val isLastChunk = chunkIdx == wordChunks.lastIndex
                val proportionalDurationMs = if (isLastChunk) {
                    (sceneDurationMs - sceneElapsedMs).coerceAtLeast(500L)
                } else {
                    val ratio = chunkWords.size.toDouble() / totalWordsInScene.toDouble()
                    (sceneDurationMs * ratio).toLong().coerceIn(500L, sceneDurationMs - sceneElapsedMs)
                }

                val startMs = currentTimeMs + sceneElapsedMs
                val endMs = startMs + proportionalDurationMs
                val wrappedLines = wrapWordsIntoLines(chunkWords, maxCharsPerLine, maxLinesPerCue)

                result.add(
                    SubtitleSegment(
                        index = cueCounter++,
                        startTimeMs = startMs,
                        endTimeMs = endMs,
                        text = wrappedLines
                    )
                )
                sceneElapsedMs += proportionalDurationMs
            }

            currentTimeMs += sceneDurationMs
        }

        return result
    }

    /**
     * Formats milliseconds into standard SRT timestamp `HH:MM:SS,mmm`.
     * Uses `Locale.US` to guarantee ASCII digits and comma separator even when the device locale is Arabic.
     */
    fun formatTimestamp(timeMs: Long): String {
        val safeMs = timeMs.coerceAtLeast(0L)
        val hours = safeMs / 3_600_000L
        val minutes = (safeMs % 3_600_000L) / 60_000L
        val seconds = (safeMs % 60_000L) / 1_000L
        val millis = safeMs % 1_000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    private fun splitWordsEvenly(words: List<String>, parts: Int): List<List<String>> {
        if (words.isEmpty() || parts <= 1) return listOf(words)
        val result = mutableListOf<List<String>>()
        val total = words.size
        var startIndex = 0
        for (i in 0 until parts) {
            val remainingWords = total - startIndex
            val remainingParts = parts - i
            val chunkSize = ((remainingWords + remainingParts - 1) / remainingParts).coerceAtLeast(1)
            val endIndex = (startIndex + chunkSize).coerceAtMost(total)
            if (startIndex < endIndex) {
                result.add(words.subList(startIndex, endIndex))
            }
            startIndex = endIndex
        }
        return result
    }

    private fun wrapWordsIntoLines(
        words: List<String>,
        maxCharsPerLine: Int,
        maxLines: Int
    ): String {
        if (words.isEmpty()) return ""
        val lines = mutableListOf<StringBuilder>()
        var currentLine = StringBuilder()

        for (word in words) {
            if (currentLine.isEmpty()) {
                currentLine.append(word)
            } else if (currentLine.length + 1 + word.length <= maxCharsPerLine || lines.size >= maxLines - 1) {
                currentLine.append(" ").append(word)
            } else {
                lines.add(currentLine)
                currentLine = StringBuilder(word)
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine)
        }
        return lines.joinToString(separator = "\n") { it.toString() }
    }
}
