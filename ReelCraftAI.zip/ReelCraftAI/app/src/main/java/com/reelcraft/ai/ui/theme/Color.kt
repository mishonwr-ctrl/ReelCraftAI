package com.reelcraft.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Studio Palette (Creator Studio Default)
val StudioObsidian = Color(0xFF0B0C14)
val StudioSurfaceDark = Color(0xFF141625)
val StudioCardDark = Color(0xFF1D2036)
val StudioVioletPrimary = Color(0xFF8B5CF6)
val StudioVioletContainer = Color(0xFF2E1B5B)
val StudioAmberAccent = Color(0xFFF59E0B)
val StudioEmeraldSuccess = Color(0xFF10B981)
val StudioCoralError = Color(0xFFEF4444)
val StudioTextPrimaryDark = Color(0xFFF8FAFC)
val StudioTextSecondaryDark = Color(0xFF94A3B8)

// Light Studio Palette
val StudioIvory = Color(0xFFF8FAFC)
val StudioSurfaceLight = Color(0xFFFFFFFF)
val StudioCardLight = Color(0xFFF1F5F9)
val StudioVioletLightPrimary = Color(0xFF6D28D9)
val StudioVioletLightContainer = Color(0xFFEDE9FE)
val StudioAmberLightAccent = Color(0xFFD97706)
val StudioTextPrimaryLight = Color(0xFF0F172A)
val StudioTextSecondaryLight = Color(0xFF475569)
