package com.reelcraft.ai.domain.validation

import com.reelcraft.ai.domain.model.AiProviderMode

data class ValidationResult(
    val isValid: Boolean,
    val fieldErrors: Map<String, String> = emptyMap()
) {
    fun errorFor(field: String): String? = fieldErrors[field]
}

object FormValidator {

    const val FIELD_TITLE = "title"
    const val FIELD_TOPIC = "topic"
    const val FIELD_SCENE_COUNT = "sceneCount"
    const val FIELD_DURATION = "duration"
    const val FIELD_SCRIPT = "fullScript"
    const val FIELD_VOICE_OVER = "voiceOverText"
    const val FIELD_VISUAL_DESC = "visualDescription"
    const val FIELD_VIDEO_PROMPT = "videoPrompt"
    const val FIELD_SCENE_DURATION = "sceneDuration"
    const val FIELD_ENDPOINT_URL = "endpointUrl"
    const val FIELD_API_KEY = "apiKey"
    const val FIELD_MODEL_NAME = "modelName"

    fun validateNewProjectForm(
        title: String,
        topic: String,
        sceneCount: Int,
        durationSeconds: Int,
        isArabic: Boolean
    ): ValidationResult {
        val errors = mutableMapOf<String, String>()

        val trimmedTitle = title.trim()
        if (trimmedTitle.isEmpty()) {
            errors[FIELD_TITLE] = if (isArabic) {
                "يرجى إدخال عنوان المشروع"
            } else {
                "Project title is required"
            }
        } else if (trimmedTitle.length < 3) {
            errors[FIELD_TITLE] = if (isArabic) {
                "يجب أن يتكون العنوان من ٣ أحرف على الأقل"
            } else {
                "Project title must be at least 3 characters"
            }
        } else if (trimmedTitle.length > 120) {
            errors[FIELD_TITLE] = if (isArabic) {
                "العنوان طويل جداً (الحد الأقصى ١٢٠ حرفاً)"
            } else {
                "Project title cannot exceed 120 characters"
            }
        }

        val trimmedTopic = topic.trim()
        if (trimmedTopic.isEmpty()) {
            errors[FIELD_TOPIC] = if (isArabic) {
                "يرجى كتابة موضوع الفيديو أو الفكرة الأساسية"
            } else {
                "Video topic or initial idea is required"
            }
        } else if (trimmedTopic.length < 10) {
            errors[FIELD_TOPIC] = if (isArabic) {
                "يرجى توضيح الفكرة بعشر كلمات أو ١٠ أحرف على الأقل للحصول على سيناريو دقيق"
            } else {
                "Please describe the topic in at least 10 characters"
            }
        }

        if (sceneCount !in 2..15) {
            errors[FIELD_SCENE_COUNT] = if (isArabic) {
                "يجب أن يتراوح عدد المشاهد بين ٢ و ١٥ مشهداً"
            } else {
                "Number of scenes must be between 2 and 15"
            }
        }

        if (durationSeconds !in listOf(30, 60, 90)) {
            errors[FIELD_DURATION] = if (isArabic) {
                "المدة المستهدفة يجب أن تكون ٣٠ أو ٦٠ أو ٩٠ ثانية"
            } else {
                "Target duration must be 30, 60, or 90 seconds"
            }
        }

        return ValidationResult(isValid = errors.isEmpty(), fieldErrors = errors)
    }

    fun validateScriptEditorForm(
        title: String,
        fullScript: String,
        isArabic: Boolean
    ): ValidationResult {
        val errors = mutableMapOf<String, String>()
        if (title.trim().length < 3) {
            errors[FIELD_TITLE] = if (isArabic) {
                "عنوان السيناريو يجب ألا يقل عن ٣ أحرف"
            } else {
                "Script title must be at least 3 characters"
            }
        }
        if (fullScript.trim().length < 15) {
            errors[FIELD_SCRIPT] = if (isArabic) {
                "النص الكامل للسيناريو قصير جداً أو فارغ"
            } else {
                "Full script cannot be empty or shorter than 15 characters"
            }
        }
        return ValidationResult(isValid = errors.isEmpty(), fieldErrors = errors)
    }

    fun validateSceneForm(
        voiceOverText: String,
        visualDescription: String,
        videoPrompt: String,
        durationSeconds: Int,
        isArabic: Boolean
    ): ValidationResult {
        val errors = mutableMapOf<String, String>()
        if (voiceOverText.trim().isEmpty()) {
            errors[FIELD_VOICE_OVER] = if (isArabic) {
                "نص التعليق الصوتي مطلوب لإنشاء المشهد والترجمة"
            } else {
                "Voice-over narration text is required"
            }
        }
        if (visualDescription.trim().isEmpty()) {
            errors[FIELD_VISUAL_DESC] = if (isArabic) {
                "الوصف البصري للمشهد مطلوب"
            } else {
                "Visual description is required"
            }
        }
        if (videoPrompt.trim().isEmpty()) {
            errors[FIELD_VIDEO_PROMPT] = if (isArabic) {
                "أمر توليد الفيديو (Video Prompt) مطلوب"
            } else {
                "Video-generation prompt is required"
            }
        }
        if (durationSeconds !in 1..120) {
            errors[FIELD_SCENE_DURATION] = if (isArabic) {
                "مدة المشهد يجب أن تكون بين ١ و ١٢٠ ثانية"
            } else {
                "Scene duration must be between 1 and 120 seconds"
            }
        }
        return ValidationResult(isValid = errors.isEmpty(), fieldErrors = errors)
    }

    fun validateAiConfigForm(
        mode: AiProviderMode,
        endpointUrl: String,
        modelName: String,
        apiKey: String,
        hasExistingApiKey: Boolean,
        isArabic: Boolean
    ): ValidationResult {
        if (mode == AiProviderMode.DEMO_LOCAL) {
            return ValidationResult(isValid = true)
        }

        val errors = mutableMapOf<String, String>()
        val trimmedUrl = endpointUrl.trim()

        if (trimmedUrl.isEmpty()) {
            errors[FIELD_ENDPOINT_URL] = if (isArabic) {
                "عنوان نقطة النهاية (Endpoint URL) مطلوب"
            } else {
                "Endpoint URL is required"
            }
        } else if (!trimmedUrl.startsWith("https://") && !trimmedUrl.startsWith("http://localhost") && !trimmedUrl.startsWith("http://10.0.2.2")) {
            errors[FIELD_ENDPOINT_URL] = if (isArabic) {
                "يجب أن يبدأ الرابط ببروتوكول آمن https://"
            } else {
                "Endpoint URL must use https:// (or localhost/10.0.2.2 for local testing)"
            }
        }

        if (modelName.trim().isEmpty()) {
            errors[FIELD_MODEL_NAME] = if (isArabic) {
                "يرجى تحديد اسم النموذج (مثل gpt-4o-mini)"
            } else {
                "Model name is required (e.g., gpt-4o-mini)"
            }
        }

        if (mode == AiProviderMode.DIRECT_API && apiKey.trim().isEmpty() && !hasExistingApiKey) {
            errors[FIELD_API_KEY] = if (isArabic) {
                "مفتاح API مطلوب للاتصال المباشر، أو اختر الوضع التجريبي المحلّي"
            } else {
                "API key is required for Direct API mode, or switch to Local Demo Mode"
            }
        }

        return ValidationResult(isValid = errors.isEmpty(), fieldErrors = errors)
    }

    /**
     * Estimates spoken narration duration in seconds based on word count.
     * Average speaking rate for short-form reels is ~2.4 words/sec (~145 words/minute).
     */
    fun estimateSpeakingDurationSeconds(text: String): Int {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return 0
        val words = cleaned.split(Regex("\\s+")).count { it.isNotBlank() }
        return ((words / 2.3).toInt()).coerceAtLeast(3)
    }
}
