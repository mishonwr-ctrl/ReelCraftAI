package com.reelcraft.ai.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import com.reelcraft.ai.domain.model.ProjectWithScenes
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.IOException

@Serializable
data class ExportedProjectJson(
    @SerialName("schemaVersion") val schemaVersion: Int = 1,
    @SerialName("exportedAtEpochMs") val exportedAtEpochMs: Long,
    @SerialName("application") val application: String = "ReelCraft AI (com.reelcraft.ai)",
    @SerialName("project") val project: VideoProjectEntity,
    @SerialName("scenes") val scenes: List<VideoSceneEntity>
)

object ProjectExporter {

    private val prettyJson = Json {
        prettyPrint = true
        encodeDefaults = true
    }

    fun formatScriptAsTxt(
        projectWithScenes: ProjectWithScenes,
        includeSceneBreakdown: Boolean = true
    ): String {
        val project = projectWithScenes.project
        val scenes = projectWithScenes.orderedScenes
        val sb = StringBuilder()

        sb.appendLine("==================================================")
        sb.appendLine("REELCRAFT AI — VIDEO SCRIPT")
        sb.appendLine("==================================================")
        sb.appendLine("Title: ${project.title}")
        sb.appendLine("Topic: ${project.topic}")
        sb.appendLine("Category: ${project.category}")
        sb.appendLine("Language: ${project.language}")
        sb.appendLine("Platform: ${project.targetPlatform}")
        sb.appendLine("Visual Style: ${project.visualStyle}")
        sb.appendLine("Target Duration: ${project.durationSeconds}s")
        if (project.isDemoContent) {
            sb.appendLine("Generation Mode: Local Demo Sample Content")
        }
        sb.appendLine("--------------------------------------------------")
        if (project.openingHook.isNotBlank()) {
            sb.appendLine()
            sb.appendLine("[OPENING HOOK]")
            sb.appendLine(project.openingHook.trim())
        }
        sb.appendLine()
        sb.appendLine("[FULL SCRIPT]")
        sb.appendLine(project.fullScript.trim())

        if (includeSceneBreakdown && scenes.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("--------------------------------------------------")
            sb.appendLine("[SCENE BREAKDOWN (${scenes.size} SCENES)]")
            sb.appendLine("--------------------------------------------------")
            for (scene in scenes) {
                sb.appendLine()
                sb.appendLine("Scene #${scene.sceneOrder} (${scene.durationSeconds}s)")
                sb.appendLine("Voice-Over: ${scene.voiceOverText}")
                sb.appendLine("Visual: ${scene.visualDescription}")
                sb.appendLine("AI Video Prompt: ${scene.videoPrompt}")
                if (scene.transition.isNotBlank()) {
                    sb.appendLine("Transition: ${scene.transition}")
                }
                if (scene.soundEffectNotes.isNotBlank()) {
                    sb.appendLine("SFX Notes: ${scene.soundEffectNotes}")
                }
            }
        }
        return sb.toString()
    }

    fun formatScenePromptsAsTxt(projectWithScenes: ProjectWithScenes): String {
        val project = projectWithScenes.project
        val scenes = projectWithScenes.orderedScenes
        val sb = StringBuilder()

        sb.appendLine("# ReelCraft AI — Video Generation Prompts")
        sb.appendLine("# Project: ${project.title}")
        sb.appendLine("# Visual Style: ${project.visualStyle} | Platform: ${project.targetPlatform}")
        sb.appendLine()

        for (scene in scenes) {
            sb.appendLine("=== SCENE #${scene.sceneOrder} (${scene.durationSeconds}s) ===")
            sb.appendLine("PROMPT:")
            sb.appendLine(scene.videoPrompt.trim())
            sb.appendLine()
            sb.appendLine("VISUAL CONTEXT:")
            sb.appendLine(scene.visualDescription.trim())
            sb.appendLine()
            sb.appendLine("VOICE-OVER:")
            sb.appendLine(scene.voiceOverText.trim())
            if (scene.transition.isNotBlank() || scene.soundEffectNotes.isNotBlank()) {
                sb.appendLine("TRANSITION / SFX: ${scene.transition} | ${scene.soundEffectNotes}")
            }
            sb.appendLine("--------------------------------------------------")
            sb.appendLine()
        }
        return sb.toString()
    }

    fun formatProjectAsJson(
        projectWithScenes: ProjectWithScenes,
        exportedAtEpochMs: Long = System.currentTimeMillis()
    ): String {
        val payload = ExportedProjectJson(
            exportedAtEpochMs = exportedAtEpochMs,
            project = projectWithScenes.project,
            scenes = projectWithScenes.orderedScenes
        )
        return prettyJson.encodeToString(payload)
    }

    /**
     * Writes UTF-8 text content to a user-selected Android Storage Access Framework (SAF) [Uri].
     */
    fun writeUtf8ToUri(context: Context, targetUri: Uri, content: String): Result<Unit> {
        return try {
            val outputStream = context.contentResolver.openOutputStream(targetUri, "wt")
                ?: return Result.failure(IOException("Unable to open output stream for selected URI"))
            outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.write(content)
                writer.flush()
            }
            Result.success(Unit)
        } catch (e: SecurityException) {
            Result.failure(IOException("Permission denied when writing file: ${e.localizedMessage}", e))
        } catch (e: Exception) {
            Result.failure(IOException("Failed to write file: ${e.localizedMessage}", e))
        }
    }

    /**
     * Creates a shareable UTF-8 file in the app's cache export directory and launches Android's share sheet.
     */
    fun shareTextFile(
        context: Context,
        fileName: String,
        mimeType: String,
        content: String
    ): Result<Intent> {
        return try {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val safeFileName = fileName.replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF]"), "_")
            val file = File(exportDir, safeFileName)
            file.writeText(content, Charsets.UTF_8)

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            Result.success(Intent.createChooser(shareIntent, fileName))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
