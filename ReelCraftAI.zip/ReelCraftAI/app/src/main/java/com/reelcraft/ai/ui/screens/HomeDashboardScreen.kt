package com.reelcraft.ai.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.preferences.StudioSettings
import com.reelcraft.ai.domain.model.AppThemeMode
import com.reelcraft.ai.domain.model.BuiltInTemplates
import com.reelcraft.ai.domain.model.ContentCategory
import com.reelcraft.ai.domain.model.QuickTemplate
import com.reelcraft.ai.domain.model.TargetPlatform
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeDashboardScreen(
    settings: StudioSettings,
    totalProjectsCount: Int,
    recentProjects: List<VideoProjectEntity>,
    onCreateNewProject: (String) -> Unit,
    onOpenProjectDetails: (Long) -> Unit,
    onOpenSavedProjects: (String) -> Unit,
    onOpenAiConfig: () -> Unit,
    onOpenSettings: () -> Unit,
    onToggleTheme: () -> Unit
) {
    val isArabic = settings.isArabic
    var dashboardSearch by rememberSaveable { mutableStateOf("") }

    val displayedRecent = if (dashboardSearch.isBlank()) {
        recentProjects
    } else {
        recentProjects.filter {
            it.title.contains(dashboardSearch, ignoreCase = true) ||
                it.topic.contains(dashboardSearch, ignoreCase = true) ||
                it.fullScript.contains(dashboardSearch, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "ReelCraft AI",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) "استوديو صناعة الفيديو القصير" else "Short-Form Video Studio",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onToggleTheme) {
                        Icon(
                            imageVector = if (settings.themeMode == AppThemeMode.LIGHT) {
                                Icons.Default.DarkMode
                            } else {
                                Icons.Default.LightMode
                            },
                            contentDescription = if (isArabic) "تبديل المظهر" else "Toggle theme"
                        )
                    }
                    IconButton(onClick = onOpenAiConfig) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = if (isArabic) "إعداد الذكاء الاصطناعي" else "AI Config"
                        )
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = if (isArabic) "الإعدادات" else "Settings"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Hero Studio Banner + Create New Video Button + Real DB Project Counter
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = if (settings.isLiveAiReady) {
                                            MaterialTheme.colorScheme.tertiary
                                        } else {
                                            MaterialTheme.colorScheme.secondary
                                        },
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (settings.isLiveAiReady) {
                                            if (isArabic) "مزود الذكاء الاصطناعي جاهز" else "Live AI Provider Ready"
                                        } else {
                                            if (isArabic) "الوضع التجريبي المحلّي مفعل" else "Local Demo Mode Active"
                                        },
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.clickable { onOpenSavedProjects("") }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FolderSpecial,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isArabic) {
                                            "المشاريع المحفوظة: $totalProjectsCount"
                                        } else {
                                            "Saved Projects: $totalProjectsCount"
                                        },
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Text(
                            text = if (isArabic) {
                                "حوّل فكرتك إلى سيناريو احترافي، ومشاهد مقسمة، وأوامر توليد فيديو، وملف ترجمة SRT في ثوانٍ."
                            } else {
                                "Turn your idea into a structured script, scene storyboard, AI video prompts, and SRT subtitles."
                            },
                            style = MaterialTheme.typography.bodyLarge
                        )

                        Button(
                            onClick = { onCreateNewProject("") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(vertical = 14.dp)
                        ) {
                            Icon(imageVector = Icons.Default.AddCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isArabic) "إنشاء مشروع فيديو جديد" else "Create New Video Project",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                }
            }

            // 2. Search Bar
            item {
                OutlinedTextField(
                    value = dashboardSearch,
                    onValueChange = { dashboardSearch = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null)
                    },
                    placeholder = {
                        Text(
                            if (isArabic) {
                                "ابحث في المشاريع حسب العنوان أو الموضوع…"
                            } else {
                                "Search projects by title or topic…"
                            }
                        )
                    },
                    trailingIcon = {
                        if (dashboardSearch.isNotBlank()) {
                            TextButton(onClick = { onOpenSavedProjects(dashboardSearch) }) {
                                Text(if (isArabic) "بحث كامل" else "All Results")
                            }
                        }
                    }
                )
            }

            // 3. Quick-Start Content Templates
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isArabic) "قوالب البدء السريع" else "Quick-Start Templates",
                        style = MaterialTheme.typography.titleLarge
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(BuiltInTemplates.templates, key = { it.id }) { template ->
                            QuickTemplateCard(
                                template = template,
                                isArabic = isArabic,
                                onClick = { onCreateNewProject(template.id) }
                            )
                        }
                    }
                }
            }

            // 4. Recently Edited Projects Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isArabic) "أحدث المشاريع المعدلة" else "Recently Edited Projects",
                        style = MaterialTheme.typography.titleLarge
                    )
                    TextButton(onClick = { onOpenSavedProjects(dashboardSearch) }) {
                        Text(if (isArabic) "عرض الكل ($totalProjectsCount)" else "View All ($totalProjectsCount)")
                    }
                }
            }

            // 5. Recent Projects List or Empty State
            if (displayedRecent.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MovieCreation,
                                contentDescription = null,
                                modifier = Modifier.size(40.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (isArabic) {
                                    "لا توجد مشاريع مطابقة حالياً"
                                } else {
                                    "No video projects found yet"
                                },
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = if (isArabic) {
                                    "اضغط على «إنشاء مشروع فيديو جديد» أو اختر قالباً جاهزاً أعلاه لتوليد أول سيناريو."
                                } else {
                                    "Tap 'Create New Video Project' or choose a template above to generate your first script."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(displayedRecent, key = { it.id }) { project ->
                    ProjectSummaryCard(
                        project = project,
                        isArabic = isArabic,
                        onClick = { onOpenProjectDetails(project.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickTemplateCard(
    template: QuickTemplate,
    isArabic: Boolean,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier
            .width(250.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = template.title(isArabic),
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = template.topic(isArabic),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = onClick,
                    label = { Text(template.category.label(isArabic)) }
                )
                AssistChip(
                    onClick = onClick,
                    label = { Text("${template.duration.seconds}s") }
                )
            }
        }
    }
}

@Composable
fun ProjectSummaryCard(
    project: VideoProjectEntity,
    isArabic: Boolean,
    onClick: () -> Unit
) {
    val category = ContentCategory.fromKey(project.category).label(isArabic)
    val platform = TargetPlatform.fromKey(project.targetPlatform).label(isArabic)
    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    val formattedDate = dateFormat.format(Date(project.updatedAt))

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = project.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (project.isDemoContent) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = if (isArabic) "تجريبي" else "Demo",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Text(
                text = project.topic,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$category • $platform • ${project.durationSeconds}s",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
