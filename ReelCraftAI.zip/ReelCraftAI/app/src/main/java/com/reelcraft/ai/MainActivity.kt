package com.reelcraft.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.reelcraft.ai.ui.navigation.ReelCraftNavHost
import com.reelcraft.ai.ui.theme.ReelCraftTheme
import com.reelcraft.ai.ui.viewmodel.ReelCraftViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ReelCraftViewModel by viewModels {
        val app = application as ReelCraftApplication
        ReelCraftViewModel.provideFactory(app.container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by viewModel.settings.collectAsState()

            ReelCraftTheme(
                themeMode = settings.themeMode,
                language = settings.language
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ReelCraftNavHost(viewModel = viewModel)
                }
            }
        }
    }
}
