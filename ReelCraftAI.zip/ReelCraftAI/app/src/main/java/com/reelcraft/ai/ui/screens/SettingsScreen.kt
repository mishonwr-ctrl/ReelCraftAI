package com.reelcraft.ai.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.data.preferences.StudioSettings
import com.reelcraft.ai.domain.model.AppLanguage
import com.reelcraft.ai.domain.model.AppThemeMode
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: StudioSettings,
    totalSavedProjects: Int,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectThemeMode: (AppThemeMode) -> Unit,
    onUpdateExportPrefs: (Int, Boolean) -> Unit,
    onUpdateSupabaseConfig: (String, String) -> Unit,
    onOpenAiConfig: () -> Unit,
    onClearAllLocalData: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isArabic = settings.isArabic
    var showClearDialog by remember { mutableStateOf(false) }

    var supabaseUrl by rememberSaveable(settings.supabaseUrl) { mutableStateOf(settings.supabaseUrl) }
    var supabaseAnonKey by rememberSaveable(settings.supabaseAnonKey) { mutableStateOf(settings.supabaseAnonKey) }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = {
                Text(if (isArabic) "مسح جميع البيانات المحلية؟" else "Clear All Local Projects?")
            },
            text = {
                Text(
                    if (isArabic) {
                        "سيؤدي هذا الإجراء إلى حذف جميع المشاريع ($totalSavedProjects) والمشاهد المحفوظة محلياً بشكل نهائي ولا يمكن التراجع عنه."
                    } else {
                        "This will permanently delete all $totalSavedProjects saved projects and scenes from your local device database."
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearDialog = false
                        onClearAllLocalData()
                        Toast.makeText(
                            context,
                            if (isArabic) "تم مسح جميع المشاريع المحلية" else "All local data cleared",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                ) {
                    Text(
                        text = if (isArabic) "حذف نهائي" else "Delete Permanently",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text(if (isArabic) "إلغاء" else "Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isArabic) "إعدادات الاستوديو" else "Studio Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isArabic) "رجوع" else "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Language Selection (Arabic Default RTL / English LTR)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "لغة التطبيق واتجاه الواجهة" else "Application Language & Layout",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AppLanguage.entries.forEach { lang ->
                                FilterChip(
                                    selected = settings.language == lang,
                                    onClick = { onSelectLanguage(lang) },
                                    label = { Text(lang.label(isArabic)) }
                                )
                            }
                        }
                    }
                }
            }

            // 2. Theme Selection (Light / Dark / System)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "المظهر والألوان" else "Appearance & Theme",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AppThemeMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = settings.themeMode == mode,
                                    onClick = { onSelectThemeMode(mode) },
                                    label = { Text(mode.label(isArabic)) }
                                )
                            }
                        }
                    }
                }
            }

            // 3. AI Provider Configuration Shortcut
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "إعداد مزود الذكاء الاصطناعي" else "AI Provider Configuration",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = settings.aiProviderMode.label(isArabic),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Button(
                            onClick = onOpenAiConfig,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Tune, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (isArabic) {
                                    "إدارة نقطة النهاية (Endpoint) ومفتاح API"
                                } else {
                                    "Configure AI Endpoint & API Key"
                                }
                            )
                        }
                    }
                }
            }

            // 4. Export & Subtitle Preferences
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "تفضيلات التصدير والترجمة (SRT)" else "Export & Subtitle Preferences",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) {
                                "مدة المقطع الافتراضية في ملف الترجمة: ${settings.defaultSrtSegmentSeconds} ثوانٍ"
                            } else {
                                "Default SRT Subtitle Segment Duration: ${settings.defaultSrtSegmentSeconds}s"
                            },
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Slider(
                            value = settings.defaultSrtSegmentSeconds.toFloat(),
                            onValueChange = {
                                onUpdateExportPrefs(it.roundToInt().coerceIn(2, 10), settings.includePromptsInTxtExport)
                            },
                            valueRange = 2f..10f,
                            steps = 7
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isArabic) {
                                    "تضمين تفاصيل المشاهد وأوامر الفيديو عند تصدير TXT"
                                } else {
                                    "Include scene prompts in .TXT script export"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            Switch(
                                checked = settings.includePromptsInTxtExport,
                                onCheckedChange = {
                                    onUpdateExportPrefs(settings.defaultSrtSegmentSeconds, it)
                                }
                            )
                        }
                    }
                }
            }

            // 5. Optional Supabase Cloud Configuration
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Cloud, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isArabic) {
                                    "الربط السحابي الاختياري (Supabase)"
                                } else {
                                    "Optional Cloud Backend (Supabase)"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (settings.isSupabaseConfigured) {
                                if (isArabic) "تم إدخال رابط ومفتاح Supabase العام (Anon Key)." else "Supabase URL and Anon Key configured."
                            } else {
                                if (isArabic) {
                                    "يعمل التطبيق حالياً بقاعدة البيانات المحلية (Room) بالكامل. لربط Supabase، أدخل رابط المشروع والمفتاح العام (Anon Key فقط — لا تضع مفتاح service_role داخل التطبيق)."
                                } else {
                                    "Running 100% on local Room database. To configure Supabase, enter your project URL and publishable Anon Key (never put service_role keys in the client)."
                                }
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = supabaseUrl,
                            onValueChange = { supabaseUrl = it },
                            label = { Text("Supabase Project URL (https://...supabase.co)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = supabaseAnonKey,
                            onValueChange = { supabaseAnonKey = it },
                            label = { Text("Supabase Publishable Anon Key") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedButton(
                            onClick = {
                                onUpdateSupabaseConfig(supabaseUrl, supabaseAnonKey)
                                Toast.makeText(
                                    context,
                                    if (isArabic) "تم حفظ إعدادات Supabase" else "Supabase settings saved",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isArabic) "حفظ إعدادات Supabase" else "Save Supabase Settings")
                        }
                    }
                }
            }

            // 6. Clear Local Data & App Information
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "إدارة البيانات ومعلومات التطبيق" else "Data Management & App Info",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "ReelCraft AI • Package: com.reelcraft.ai • v1.0.0 (Min SDK 26)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = { showClearDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (isArabic) {
                                    "مسح جميع البيانات المحلية ($totalSavedProjects مشروع)"
                                } else {
                                    "Clear All Local Data ($totalSavedProjects projects)"
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
