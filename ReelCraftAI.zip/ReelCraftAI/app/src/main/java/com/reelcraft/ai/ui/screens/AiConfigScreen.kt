package com.reelcraft.ai.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.reelcraft.ai.data.preferences.StudioSettings
import com.reelcraft.ai.domain.model.AiProviderMode
import com.reelcraft.ai.domain.validation.FormValidator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiConfigScreen(
    settings: StudioSettings,
    maskedApiKey: String,
    onSaveAiConfig: (AiProviderMode, String, String, String?) -> Unit,
    onClearApiKey: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isArabic = settings.isArabic

    var selectedMode by rememberSaveable(settings.aiProviderMode) {
        mutableStateOf(settings.aiProviderMode)
    }
    var endpointUrl by rememberSaveable(settings.aiEndpointUrl) {
        mutableStateOf(settings.aiEndpointUrl)
    }
    var modelName by rememberSaveable(settings.aiModelName) {
        mutableStateOf(settings.aiModelName)
    }
    var apiKeyInput by rememberSaveable { mutableStateOf("") }
    var showApiKey by rememberSaveable { mutableStateOf(false) }
    var fieldErrors by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (isArabic) "إعداد مزود الذكاء الاصطناعي" else "AI Provider Configuration")
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isArabic) "رجوع" else "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Security Guidance Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isArabic) {
                                "تنبيه أمني للإنتاج: لا تقم أبداً بتضمين مفاتيح API الإنتاجية داخل ملف APK. للاستخدام الإنتاجي، اختر «خادم وسيط آمن (Supabase Edge Function)» بحيث يبقى مفتاح الذكاء الاصطناعي مخزناً على الخادم فقط."
                            } else {
                                "Production Security Notice: Never embed privileged production API keys inside an APK. For production releases, select 'Server-Side Proxy (Supabase Edge Function)' so credentials remain strictly on the server."
                            },
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // Provider Mode Selection
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (isArabic) "اختر وضع تشغيل الذكاء الاصطناعي" else "Select AI Operation Mode",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        AiProviderMode.entries.forEach { mode ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedMode == mode,
                                    onClick = {
                                        selectedMode = mode
                                        fieldErrors = emptyMap()
                                    }
                                )
                                Text(
                                    text = mode.label(isArabic),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        }
                    }
                }
            }

            if (selectedMode != AiProviderMode.DEMO_LOCAL) {
                item {
                    OutlinedTextField(
                        value = endpointUrl,
                        onValueChange = {
                            endpointUrl = it
                            fieldErrors = fieldErrors - FormValidator.FIELD_ENDPOINT_URL
                        },
                        label = {
                            Text(
                                if (selectedMode == AiProviderMode.SERVER_PROXY) {
                                    if (isArabic) "رابط الخادم الوسيط (Edge Function URL) *" else "Server Proxy URL (Edge Function) *"
                                } else {
                                    if (isArabic) "رابط نقطة النهاية (OpenAI-Compatible Base URL) *" else "AI Endpoint Base URL *"
                                }
                            )
                        },
                        isError = fieldErrors.containsKey(FormValidator.FIELD_ENDPOINT_URL),
                        supportingText = {
                            fieldErrors[FormValidator.FIELD_ENDPOINT_URL]?.let { Text(it) }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = modelName,
                        onValueChange = {
                            modelName = it
                            fieldErrors = fieldErrors - FormValidator.FIELD_MODEL_NAME
                        },
                        label = {
                            Text(if (isArabic) "اسم النموذج (مثل gpt-4o-mini) *" else "Model Name (e.g., gpt-4o-mini) *")
                        },
                        isError = fieldErrors.containsKey(FormValidator.FIELD_MODEL_NAME),
                        supportingText = {
                            fieldErrors[FormValidator.FIELD_MODEL_NAME]?.let { Text(it) }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = {
                            apiKeyInput = it
                            fieldErrors = fieldErrors - FormValidator.FIELD_API_KEY
                        },
                        label = {
                            Text(
                                if (selectedMode == AiProviderMode.SERVER_PROXY) {
                                    if (isArabic) "رمز مصادقة المستخدم / Anon Token (اختياري)" else "Proxy Auth / Anon Token (Optional)"
                                } else {
                                    if (isArabic) "مفتاح API السري (يُحفظ مشفراً محلياً) *" else "API Key (Encrypted in Device Storage) *"
                                }
                            )
                        },
                        placeholder = {
                            if (maskedApiKey.isNotBlank()) {
                                Text(
                                    if (isArabic) {
                                        "محفوظ حالياً: $maskedApiKey (اتركه فارغاً للإبقاء عليه)"
                                    } else {
                                        "Stored: $maskedApiKey (Leave blank to keep)"
                                    }
                                )
                            }
                        },
                        visualTransformation = if (showApiKey) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        trailingIcon = {
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle key visibility"
                                )
                            }
                        },
                        isError = fieldErrors.containsKey(FormValidator.FIELD_API_KEY),
                        supportingText = {
                            fieldErrors[FormValidator.FIELD_API_KEY]?.let { Text(it) }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (settings.apiKeyConfigured) {
                    item {
                        OutlinedButton(
                            onClick = {
                                onClearApiKey()
                                apiKeyInput = ""
                                Toast.makeText(
                                    context,
                                    if (isArabic) "تم مسح مفتاح API المحفوظ" else "Stored API key cleared",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isArabic) "مسح مفتاح API المحفوظ" else "Clear Stored API Key")
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        val validation = FormValidator.validateAiConfigForm(
                            mode = selectedMode,
                            endpointUrl = endpointUrl,
                            modelName = modelName,
                            apiKey = apiKeyInput,
                            hasExistingApiKey = settings.apiKeyConfigured,
                            isArabic = isArabic
                        )
                        fieldErrors = validation.fieldErrors
                        if (validation.isValid) {
                            val keyToUpdate = if (apiKeyInput.isBlank()) null else apiKeyInput
                            onSaveAiConfig(selectedMode, endpointUrl, modelName, keyToUpdate)
                            Toast.makeText(
                                context,
                                if (isArabic) "تم حفظ إعدادات الذكاء الاصطناعي" else "AI configuration saved",
                                Toast.LENGTH_SHORT
                            ).show()
                            onNavigateBack()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    Text(if (isArabic) "حفظ الإعدادات" else "Save AI Configuration")
                }
            }
        }
    }
}
