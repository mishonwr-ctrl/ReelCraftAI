package com.reelcraft.ai.ai

import com.reelcraft.ai.domain.model.ScriptLanguage

/**
 * Local Demo Mode provider that works offline when no external AI service is configured.
 * Explicitly sets `isDemoContent = true` so the UI always displays a clear Demo Mode badge
 * and never misleads the user into thinking a live cloud LLM generated the output.
 */
class DemoAiScriptProvider : AiScriptProvider {

    override suspend fun generateProject(request: AiGenerationRequest): AiGenerationResult {
        val sceneCount = request.numberOfScenes.coerceIn(2, 15)
        val totalSeconds = request.targetDuration.seconds
        val perSceneSeconds = (totalSeconds / sceneCount).coerceAtLeast(4)
        val stylePrompt = request.visualStyle.promptDescriptor

        val scenes = (1..sceneCount).map { idx ->
            buildDemoScene(
                sceneIndex = idx,
                totalScenes = sceneCount,
                perSceneSeconds = perSceneSeconds,
                request = request,
                stylePrompt = stylePrompt
            )
        }

        val hook = when (request.scriptLanguage) {
            ScriptLanguage.MSA_ARABIC ->
                "هل توقفت يوماً لتسأل نفسك: ما السر الحقيقي وراء ${request.topic}؟ في الثواني القادمة ستكتشف إجابة غير متوقعة!"
            ScriptLanguage.EGYPTIAN_ARABIC ->
                "عمرك فكرت إيه اللي بيحصل فعلاً في موضوع ${request.topic}؟ تعال أقولك السر في ثواني!"
            ScriptLanguage.ENGLISH ->
                "Have you ever wondered what really happens behind ${request.topic}? Watch the next ${totalSeconds} seconds closely!"
        }

        val fullScript = scenes.joinToString(separator = "\n\n") { it.voiceOverText }

        val projectDto = AiGeneratedProjectDto(
            projectTitle = request.projectTitle.trim(),
            videoHook = hook,
            completeScript = fullScript,
            estimatedDurationSeconds = scenes.sumOf { it.estimatedDurationSeconds },
            scenes = scenes
        )

        return AiGenerationResult.Success(
            data = projectDto,
            isDemoContent = true,
            providerLabel = "DEMO_LOCAL"
        )
    }

    private fun buildDemoScene(
        sceneIndex: Int,
        totalScenes: Int,
        perSceneSeconds: Int,
        request: AiGenerationRequest,
        stylePrompt: String
    ): AiGeneratedSceneDto {
        val topic = request.topic.trim()
        return when (request.scriptLanguage) {
            ScriptLanguage.MSA_ARABIC -> {
                val vo = when (sceneIndex) {
                    1 -> "هل تعلم أن $topic يخفي تفاصيل مدهشة لا يلاحظها معظم الناس في حياتهم اليومية؟"
                    totalScenes -> "والآن بعد أن عرفت هذه الحقيقة حول $topic، شاركنا رأيك في التعليقات وتابعنا للمزيد!"
                    else -> "في الخطوة رقم $sceneIndex، نلاحظ كيف تتفاعل العناصر الأساسية في $topic لتصنع فارقاً واضحاً وملموساً."
                }
                val visual = when (sceneIndex) {
                    1 -> "لقطة افتتاحية قريبة وجذابة تبرز العنصر الرئيسي في ($topic) مع إضاءة درامية وحركة كاميرا بطيئة للأمام."
                    totalScenes -> "لقطة ختامية ملهمة تلخص الفكرة الرئيسية حول ($topic) مع مساحة واضحة لظهور نص الدعوة للتفاعل."
                    else -> "مشهد تفصيلي رقم $sceneIndex يوضح الجوانب العملية والجمالية لموضوع ($topic) بزوايا تصوير ديناميكية."
                }
                val transition = if (sceneIndex == 1) "Fade In + Quick Zoom" else if (sceneIndex == totalScenes) "Smooth Fade Out" else "Whip Pan / Match Cut"
                val sfx = if (sceneIndex == 1) "Whoosh + Deep Cinematic Riser" else "Subtle Ambient Pulse + Soft Click"
                val prompt = "Scene $sceneIndex of $totalScenes for ${request.targetPlatform.labelEn}: Visual representation of $topic, stage $sceneIndex, $stylePrompt, smooth camera motion, high detail"

                AiGeneratedSceneDto(
                    sceneNumber = sceneIndex,
                    voiceOverText = vo,
                    estimatedDurationSeconds = perSceneSeconds,
                    visualDescription = visual,
                    videoGenerationPrompt = prompt,
                    suggestedTransition = transition,
                    soundEffectSuggestions = sfx
                )
            }

            ScriptLanguage.EGYPTIAN_ARABIC -> {
                val vo = when (sceneIndex) {
                    1 -> "تخيل معايا كدة لو فهمنا سر $topic بطريقة بسيطة ومن غير أي تعقيد!"
                    totalScenes -> "لو عجبتك الفكرة دي عن $topic، اعمل لايك وابعت الفيديو لصاحبك المهتم بالموضوع ده!"
                    else -> "الحاجة التانية المهمة في المشهد رقم $sceneIndex إن $topic بيأثر بشكل مباشر على النتيجة النهائية اللي بنشوفها."
                }
                val visual = "كادر بصري للمشهد رقم $sceneIndex يعرض ($topic) بأسلوب ${request.visualStyle.labelAr} مع حركة كاميرا سلسة."
                val prompt = "Scene $sceneIndex of $totalScenes (${request.targetPlatform.aspectRatio}): $topic illustrated with authentic details, $stylePrompt"

                AiGeneratedSceneDto(
                    sceneNumber = sceneIndex,
                    voiceOverText = vo,
                    estimatedDurationSeconds = perSceneSeconds,
                    visualDescription = visual,
                    videoGenerationPrompt = prompt,
                    suggestedTransition = if (sceneIndex == 1) "Zoom In" else "Quick Cut",
                    soundEffectSuggestions = "Light Pop + Warm Background Beat"
                )
            }

            ScriptLanguage.ENGLISH -> {
                val vo = when (sceneIndex) {
                    1 -> "Here is what almost everyone gets wrong about $topic—and why it matters right now."
                    totalScenes -> "That is the core secret behind $topic. Drop your thoughts below and follow for the next breakdown!"
                    else -> "In part $sceneIndex, look closely at how $topic transforms the entire perspective step by step."
                }
                val visual = "Scene $sceneIndex storyboard: Dynamic framing showcasing $topic in ${request.visualStyle.labelEn} style with crisp focal depth."
                val prompt = "Scene $sceneIndex of $totalScenes: $topic, dynamic camera movement, $stylePrompt"

                AiGeneratedSceneDto(
                    sceneNumber = sceneIndex,
                    voiceOverText = vo,
                    estimatedDurationSeconds = perSceneSeconds,
                    visualDescription = visual,
                    videoGenerationPrompt = prompt,
                    suggestedTransition = if (sceneIndex == 1) "Hard Cut + Zoom" else "Match Cut",
                    soundEffectSuggestions = if (sceneIndex == 1) "Cinematic Bass Drop" else "Subtle Whoosh"
                )
            }
        }
    }
}
