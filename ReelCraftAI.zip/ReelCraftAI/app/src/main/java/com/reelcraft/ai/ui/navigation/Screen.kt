package com.reelcraft.ai.ui.navigation

sealed class Screen(val route: String) {
    data object Splash : Screen("splash")
    data object HomeDashboard : Screen("home_dashboard")
    data object CreateProject : Screen("create_project?templateId={templateId}") {
        fun createRoute(templateId: String = ""): String =
            "create_project?templateId=$templateId"
    }
    data object SavedProjects : Screen("saved_projects")
    data object ProjectDetails : Screen("project_details/{projectId}") {
        fun createRoute(projectId: Long): String = "project_details/$projectId"
    }
    data object ScriptEditor : Screen("script_editor/{projectId}") {
        fun createRoute(projectId: Long): String = "script_editor/$projectId"
    }
    data object SceneEditor : Screen("scene_editor/{projectId}") {
        fun createRoute(projectId: Long): String = "scene_editor/$projectId"
    }
    data object Export : Screen("export/{projectId}") {
        fun createRoute(projectId: Long): String = "export/$projectId"
    }
    data object Settings : Screen("settings")
    data object AiConfig : Screen("ai_config")
}
