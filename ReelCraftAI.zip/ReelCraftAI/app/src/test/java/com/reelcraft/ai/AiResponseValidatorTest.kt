package com.reelcraft.ai

import com.reelcraft.ai.ai.AiResponseValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AiResponseValidatorTest {

    @Test
    fun `parseAndValidate extracts JSON from markdown code fences and validates scenes`() {
        val rawResponse = """
            ```json
            {
              "projectTitle": "أسرار مكتبة الإسكندرية",
              "videoHook": "هل تعلم ماذا كان يوجد داخل أعظم مكتبة في العالم القديم؟",
              "completeScript": "هل تعلم ماذا كان يوجد داخل أعظم مكتبة في العالم القديم؟ لنتعرف على التفاصيل.",
              "estimatedDurationSeconds": 60,
              "scenes": [
                {
                  "sceneNumber": 1,
                  "voiceOverText": "هل تعلم ماذا كان يوجد داخل أعظم مكتبة في العالم القديم؟",
                  "estimatedDurationSeconds": 10,
                  "visualDescription": "لقطة بانورامية لمكتبة الإسكندرية القديمة",
                  "videoGenerationPrompt": "Ancient Library of Alexandria grand hall, cinematic lighting, 9:16",
                  "suggestedTransition": "Fade In",
                  "soundEffectSuggestions": "Ancient flute + ambient hall"
                }
              ]
            }
            ```
        """.trimIndent()

        val result = AiResponseValidator.parseAndValidate(
            rawContent = rawResponse,
            fallbackTitle = "Fallback Title",
            targetDurationSeconds = 60
        )

        assertTrue(result.isSuccess)
        val dto = result.getOrThrow()
        assertEquals("أسرار مكتبة الإسكندرية", dto.projectTitle)
        assertEquals(1, dto.scenes.size)
        assertEquals(1, dto.scenes.first().sceneNumber)
    }

    @Test
    fun `parseAndValidate fails gracefully on malformed JSON or empty scenes`() {
        val malformed = AiResponseValidator.parseAndValidate(
            rawContent = "{ invalid json ",
            fallbackTitle = "Fallback",
            targetDurationSeconds = 30
        )
        assertFalse(malformed.isSuccess)

        val emptyScenes = AiResponseValidator.parseAndValidate(
            rawContent = """{"projectTitle":"Test","scenes":[]}""",
            fallbackTitle = "Fallback",
            targetDurationSeconds = 30
        )
        assertFalse(emptyScenes.isSuccess)
    }
}
