package com.reelcraft.ai

import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import com.reelcraft.ai.domain.model.ProjectWithScenes
import com.reelcraft.ai.util.ProjectExporter
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectExporterTest {

    private val sampleProject = ProjectWithScenes(
        project = VideoProjectEntity(
            id = 42L,
            title = "رحلة إلى المريخ",
            topic = "استكشاف الكوكب الأحمر",
            category = "EDUCATIONAL_FACTS",
            language = "MSA_ARABIC",
            targetPlatform = "TIKTOK",
            visualStyle = "CINEMATIC",
            durationSeconds = 60,
            openingHook = "ماذا لو استيقظت غداً على سطح المريخ؟",
            fullScript = "ماذا لو استيقظت غداً على سطح المريخ؟ الجاذبية هناك ثلث جاذبية الأرض.",
            isDemoContent = true,
            createdAt = 1700000000000L,
            updatedAt = 1700000050000L
        ),
        scenes = listOf(
            VideoSceneEntity(
                id = 101L,
                projectId = 42L,
                sceneOrder = 1,
                voiceOverText = "ماذا لو استيقظت غداً على سطح المريخ؟",
                durationSeconds = 10,
                visualDescription = "رائد فضاء ينظر إلى أفق المريخ الأحمر",
                videoPrompt = "Astronaut standing on rusty red Martian ridge at sunrise, cinematic 9:16",
                transition = "Fade In",
                soundEffectNotes = "Low Martian wind"
            )
        )
    )

    @Test
    fun `formatProjectAsJson includes metadata script and all scene data`() {
        val json = ProjectExporter.formatProjectAsJson(sampleProject, exportedAtEpochMs = 1700000100000L)
        assertTrue(json.contains("\"title\": \"رحلة إلى المريخ\""))
        assertTrue(json.contains("\"fullScript\":"))
        assertTrue(json.contains("\"videoPrompt\": \"Astronaut standing on rusty red Martian ridge"))
        assertTrue(json.contains("\"sceneOrder\": 1"))
    }

    @Test
    fun `formatScriptAsTxt and formatScenePromptsAsTxt include expected sections`() {
        val txt = ProjectExporter.formatScriptAsTxt(sampleProject, includeSceneBreakdown = true)
        assertTrue(txt.contains("[OPENING HOOK]"))
        assertTrue(txt.contains("[FULL SCRIPT]"))
        assertTrue(txt.contains("Scene #1 (10s)"))

        val promptsTxt = ProjectExporter.formatScenePromptsAsTxt(sampleProject)
        assertTrue(promptsTxt.contains("=== SCENE #1 (10s) ==="))
        assertTrue(promptsTxt.contains("Astronaut standing on rusty red Martian ridge"))
    }
}
