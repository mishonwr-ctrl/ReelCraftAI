package com.reelcraft.ai

import com.reelcraft.ai.data.local.dao.ProjectDao
import com.reelcraft.ai.data.local.dao.SceneDao
import com.reelcraft.ai.data.local.entity.VideoProjectEntity
import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import com.reelcraft.ai.data.repository.ProjectRepository
import com.reelcraft.ai.domain.model.ProjectWithScenes
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Pure-JVM repository test verifying project creation, script editing,
 * persistent scene reordering, scene deletion reindexing, and cascading project deletion.
 */
class ProjectRepositoryAndSceneOrderTest {

    private class FakeStore {
        val projects = MutableStateFlow<List<VideoProjectEntity>>(emptyList())
        val scenes = MutableStateFlow<List<VideoSceneEntity>>(emptyList())
        var nextProjectId = 1L
        var nextSceneId = 1L
    }

    private val store = FakeStore()

    private val fakeProjectDao = object : ProjectDao {
        override suspend fun insertProject(project: VideoProjectEntity): Long {
            val id = if (project.id == 0L) store.nextProjectId++ else project.id
            val assigned = project.copy(id = id)
            store.projects.value = store.projects.value.filterNot { it.id == id } + assigned
            return id
        }

        override suspend fun updateProject(project: VideoProjectEntity) {
            store.projects.value = store.projects.value.map { if (it.id == project.id) project else it }
        }

        override suspend fun deleteProject(project: VideoProjectEntity) {
            deleteProjectById(project.id)
        }

        override suspend fun deleteProjectById(projectId: Long) {
            store.projects.value = store.projects.value.filterNot { it.id == projectId }
            // Simulate SQLite ON DELETE CASCADE
            store.scenes.value = store.scenes.value.filterNot { it.projectId == projectId }
        }

        override suspend fun deleteAllProjects() {
            store.projects.value = emptyList()
            store.scenes.value = emptyList()
        }

        override suspend fun getProjectById(projectId: Long): VideoProjectEntity? =
            store.projects.value.firstOrNull { it.id == projectId }

        override fun observeProjectById(projectId: Long): Flow<VideoProjectEntity?> =
            store.projects.map { list -> list.firstOrNull { it.id == projectId } }

        override suspend fun getProjectWithScenes(projectId: Long): ProjectWithScenes? {
            val p = getProjectById(projectId) ?: return null
            val s = store.scenes.value.filter { it.projectId == projectId }.sortedBy { it.sceneOrder }
            return ProjectWithScenes(p, s)
        }

        override fun observeProjectWithScenes(projectId: Long): Flow<ProjectWithScenes?> =
            store.projects.map { getProjectWithScenes(projectId) }

        override fun observeAllProjectsSortedByLastModified(): Flow<List<VideoProjectEntity>> =
            store.projects.map { list -> list.sortedByDescending { it.updatedAt } }

        override fun observeRecentProjects(limit: Int): Flow<List<VideoProjectEntity>> =
            store.projects.map { list -> list.sortedByDescending { it.updatedAt }.take(limit) }

        override fun observeTotalProjectCount(): Flow<Int> =
            store.projects.map { it.size }

        override fun searchProjects(query: String, category: String): Flow<List<VideoProjectEntity>> =
            store.projects.map { list ->
                list.filter {
                    (query.isEmpty() || it.title.contains(query, true) || it.topic.contains(query, true)) &&
                        (category.isEmpty() || it.category == category)
                }.sortedByDescending { it.updatedAt }
            }

        override suspend fun touchProjectTimestamp(projectId: Long, timestamp: Long) {
            store.projects.value = store.projects.value.map {
                if (it.id == projectId) it.copy(updatedAt = timestamp) else it
            }
        }
    }

    private val fakeSceneDao = object : SceneDao {
        override fun observeScenesForProject(projectId: Long): Flow<List<VideoSceneEntity>> =
            store.scenes.map { list -> list.filter { it.projectId == projectId }.sortedBy { it.sceneOrder } }

        override suspend fun getScenesForProject(projectId: Long): List<VideoSceneEntity> =
            store.scenes.value.filter { it.projectId == projectId }.sortedBy { it.sceneOrder }

        override suspend fun insertScene(scene: VideoSceneEntity): Long {
            val id = if (scene.id == 0L) store.nextSceneId++ else scene.id
            store.scenes.value = store.scenes.value + scene.copy(id = id)
            return id
        }

        override suspend fun insertScenes(scenes: List<VideoSceneEntity>): List<Long> =
            scenes.map { insertScene(it) }

        override suspend fun updateScene(scene: VideoSceneEntity) {
            store.scenes.value = store.scenes.value.map { if (it.id == scene.id) scene else it }
        }

        override suspend fun updateScenes(scenes: List<VideoSceneEntity>) {
            scenes.forEach { updateScene(it) }
        }

        override suspend fun deleteScene(scene: VideoSceneEntity) {
            deleteSceneById(scene.id)
        }

        override suspend fun deleteSceneById(sceneId: Long) {
            store.scenes.value = store.scenes.value.filterNot { it.id == sceneId }
        }

        override suspend fun deleteScenesForProject(projectId: Long) {
            store.scenes.value = store.scenes.value.filterNot { it.projectId == projectId }
        }

        override suspend fun updateSceneOrder(sceneId: Long, newOrder: Int) {
            store.scenes.value = store.scenes.value.map {
                if (it.id == sceneId) it.copy(sceneOrder = newOrder) else it
            }
        }
    }

    @Test
    fun `create edit reorder and cascade delete project workflow`() = runTest {
        val repo = ProjectRepository(fakeProjectDao, fakeSceneDao)

        val projectId = repo.createProjectWithScenes(
            project = VideoProjectEntity(
                title = "مشروع تجريبي",
                topic = "الذكاء الاصطناعي في صناعة الفيديو",
                category = "EDUCATIONAL_FACTS",
                language = "MSA_ARABIC",
                targetPlatform = "TIKTOK",
                visualStyle = "CINEMATIC",
                durationSeconds = 30,
                openingHook = "مقدمة",
                fullScript = "النص الكامل للمشروع التجريبي",
                createdAt = 0L,
                updatedAt = 0L
            ),
            scenes = listOf(
                VideoSceneEntity(
                    projectId = 0L,
                    sceneOrder = 1,
                    voiceOverText = "المشهد الأول",
                    durationSeconds = 10,
                    visualDescription = "وصف ١",
                    videoPrompt = "Prompt 1"
                ),
                VideoSceneEntity(
                    projectId = 0L,
                    sceneOrder = 2,
                    voiceOverText = "المشهد الثاني",
                    durationSeconds = 10,
                    visualDescription = "وصف ٢",
                    videoPrompt = "Prompt 2"
                ),
                VideoSceneEntity(
                    projectId = 0L,
                    sceneOrder = 3,
                    voiceOverText = "المشهد الثالث",
                    durationSeconds = 10,
                    visualDescription = "وصف ٣",
                    videoPrompt = "Prompt 3"
                )
            )
        )

        assertEquals(1, repo.observeTotalProjectCount().first())

        val initial = repo.getProjectWithScenes(projectId)!!
        assertEquals(3, initial.orderedScenes.size)
        assertEquals("المشهد الأول", initial.orderedScenes[0].voiceOverText)

        // Reorder: move Scene 3 to position 1
        val reorderedInput = listOf(
            initial.orderedScenes[2],
            initial.orderedScenes[0],
            initial.orderedScenes[1]
        )
        repo.reorderScenes(projectId, reorderedInput)

        val afterReorder = repo.getProjectWithScenes(projectId)!!
        assertEquals("المشهد الثالث", afterReorder.orderedScenes[0].voiceOverText)
        assertEquals(1, afterReorder.orderedScenes[0].sceneOrder)
        assertEquals("المشهد الأول", afterReorder.orderedScenes[1].voiceOverText)
        assertEquals(2, afterReorder.orderedScenes[1].sceneOrder)

        // Delete middle scene and verify sequential reindexing
        repo.deleteSceneAndReindex(projectId, afterReorder.orderedScenes[1].id)
        val afterDeleteScene = repo.getProjectWithScenes(projectId)!!
        assertEquals(2, afterDeleteScene.orderedScenes.size)
        assertEquals(listOf(1, 2), afterDeleteScene.orderedScenes.map { it.sceneOrder })

        // Delete project and verify cascade deletion of scenes
        repo.deleteProject(projectId)
        assertNull(repo.getProjectWithScenes(projectId))
        assertEquals(0, fakeSceneDao.getScenesForProject(projectId).size)
    }
}
