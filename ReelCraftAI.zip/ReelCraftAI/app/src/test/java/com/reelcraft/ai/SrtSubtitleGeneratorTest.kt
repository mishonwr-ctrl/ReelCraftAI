package com.reelcraft.ai

import com.reelcraft.ai.data.local.entity.VideoSceneEntity
import com.reelcraft.ai.util.SrtSubtitleGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SrtSubtitleGeneratorTest {

    @Test
    fun `formatTimestamp formats hours minutes seconds and milliseconds with comma separator`() {
        assertEquals("00:00:00,000", SrtSubtitleGenerator.formatTimestamp(0L))
        assertEquals("00:00:04,500", SrtSubtitleGenerator.formatTimestamp(4_500L))
        assertEquals("00:01:05,250", SrtSubtitleGenerator.formatTimestamp(65_250L))
        assertEquals("01:02:03,009", SrtSubtitleGenerator.formatTimestamp(3_723_009L))
    }

    @Test
    fun `generateSrt produces valid numbered cues and preserves Arabic UTF-8 text`() {
        val scenes = listOf(
            VideoSceneEntity(
                id = 1L,
                projectId = 10L,
                sceneOrder = 1,
                voiceOverText = "مرحباً بكم في استوديو صناعة الفيديوهات القصيرة بالذكاء الاصطناعي.",
                durationSeconds = 6,
                visualDescription = "مشهد افتتاحي",
                videoPrompt = "Opening cinematic studio shot"
            ),
            VideoSceneEntity(
                id = 2L,
                projectId = 10L,
                sceneOrder = 2,
                voiceOverText = "في هذا المشهد نشرح كيفية تقسيم النص إلى ملف ترجمة احترافي.",
                durationSeconds = 8,
                visualDescription = "مشهد تفصيلي",
                videoPrompt = "Detailed close-up of timeline"
            )
        )

        val srt = SrtSubtitleGenerator.generateSrt(
            scenes = scenes,
            maxSegmentDurationSeconds = 4
        )

        assertTrue(srt.startsWith("1\n00:00:00,000 --> "))
        assertTrue(srt.contains("مرحباً بكم"))
        assertTrue(srt.contains("ملف ترجمة احترافي"))
        assertTrue(srt.contains("00:00:14,000"))
    }
}
