package com.reelcraft.ai

import com.reelcraft.ai.domain.model.AiProviderMode
import com.reelcraft.ai.domain.validation.FormValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FormValidatorTest {

    @Test
    fun `validateNewProjectForm rejects blank title and short topic`() {
        val result = FormValidator.validateNewProjectForm(
            title = "  ",
            topic = "قصير",
            sceneCount = 5,
            durationSeconds = 60,
            isArabic = true
        )
        assertFalse(result.isValid)
        assertNotNull(result.errorFor(FormValidator.FIELD_TITLE))
        assertNotNull(result.errorFor(FormValidator.FIELD_TOPIC))
    }

    @Test
    fun `validateNewProjectForm accepts valid Arabic project inputs`() {
        val result = FormValidator.validateNewProjectForm(
            title = "أسرار الثقوب السوداء في الفضاء",
            topic = "شرح مبسط لكيفية تباطؤ الزمن بالقرب من أفق الحدث للثقب الأسود",
            sceneCount = 5,
            durationSeconds = 60,
            isArabic = true
        )
        assertTrue(result.isValid)
        assertTrue(result.fieldErrors.isEmpty())
    }

    @Test
    fun `validateNewProjectForm rejects invalid scene count and duration`() {
        val result = FormValidator.validateNewProjectForm(
            title = "Valid Title",
            topic = "A sufficiently detailed video topic for testing validation",
            sceneCount = 25,
            durationSeconds = 45,
            isArabic = false
        )
        assertFalse(result.isValid)
        assertNotNull(result.errorFor(FormValidator.FIELD_SCENE_COUNT))
        assertNotNull(result.errorFor(FormValidator.FIELD_DURATION))
    }

    @Test
    fun `validateSceneForm requires voiceOver, visualDescription, videoPrompt, and valid duration`() {
        val invalid = FormValidator.validateSceneForm(
            voiceOverText = "",
            visualDescription = "",
            videoPrompt = "",
            durationSeconds = 0,
            isArabic = false
        )
        assertFalse(invalid.isValid)
        assertEquals(4, invalid.fieldErrors.size)

        val valid = FormValidator.validateSceneForm(
            voiceOverText = "هل تعلم أن الضوء لا يستطيع الإفلات من الجاذبية الهائلة؟",
            visualDescription = "لقطة سينمائية لثقب أسود محاط بقرص متوهج",
            videoPrompt = "Cinematic supermassive black hole with glowing accretion disk, 9:16 vertical",
            durationSeconds = 12,
            isArabic = true
        )
        assertTrue(valid.isValid)
    }

    @Test
    fun `validateAiConfigForm allows Demo Mode without endpoint or API key`() {
        val demoCheck = FormValidator.validateAiConfigForm(
            mode = AiProviderMode.DEMO_LOCAL,
            endpointUrl = "",
            modelName = "",
            apiKey = "",
            hasExistingApiKey = false,
            isArabic = true
        )
        assertTrue(demoCheck.isValid)
    }

    @Test
    fun `validateAiConfigForm enforces https and API key in Direct API mode`() {
        val insecure = FormValidator.validateAiConfigForm(
            mode = AiProviderMode.DIRECT_API,
            endpointUrl = "http://insecure-domain.com/v1",
            modelName = "gpt-4o-mini",
            apiKey = "",
            hasExistingApiKey = false,
            isArabic = false
        )
        assertFalse(insecure.isValid)
        assertNotNull(insecure.errorFor(FormValidator.FIELD_ENDPOINT_URL))
        assertNotNull(insecure.errorFor(FormValidator.FIELD_API_KEY))
    }
}
