# ReelCraft AI ProGuard / R8 Rules
-keepattributes *Annotation*,InnerClasses,Signature

# Kotlinx Serialization
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.reelcraft.ai.**$$serializer { *; }
-keepclassmembers class com.reelcraft.ai.** {
    *** Companion;
}
-keepclasseswithmembers class com.reelcraft.ai.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Retrofit & OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# Room Database
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
