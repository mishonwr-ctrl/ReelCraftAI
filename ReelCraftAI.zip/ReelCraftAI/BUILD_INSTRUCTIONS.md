# ReelCraft AI — Build, Installation & Cloud Setup Instructions

## 1. Prerequisites

- **Android Studio**: Ladybug (2024.2.1) or newer (or Android command-line tools with SDK Platform 35 and Build-Tools 35.0.0)
- **JDK**: Java 17 (configured automatically by Android Studio's embedded JBR 17)
- **Minimum Android Device / Emulator**: Android 8.0 (API 26) or higher

---

## 2. Opening the Project in Android Studio

1. Extract `ReelCraft-AI-Android-Project.zip` to a local folder.
2. Launch **Android Studio** -> **Open** -> select the `ReelCraftAI` directory.
3. Android Studio will automatically create `local.properties` pointing to your local Android SDK (`sdk.dir`) and download the Gradle 8.9 distribution defined in `gradle/wrapper/gradle-wrapper.properties`.
4. Wait for **Gradle Sync** to finish.

---

## 3. Building the Debug APK

### Option A: From Android Studio
1. Open the top menu: **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
2. Once finished, click **Locate** in the notification banner.
3. The generated debug APK is located at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

### Option B: From the Terminal
Run from the project root directory:
```bash
# If using the Gradle wrapper (after Android Studio sync or running `gradle wrapper`):
./gradlew assembleDebug

# Or using a system-installed Gradle 8.9+:
gradle assembleDebug
```

---

## 4. Installing the APK on an Android Phone

1. On your Android phone, enable **Developer Options** and toggle on **USB Debugging**.
2. Connect the phone to your computer via USB and accept the RSA debugging prompt.
3. Run:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
   Alternatively, copy `app-debug.apk` to your phone and open it with the Files app to install.

---

## 5. Running Automated Tests

### Pure-JVM Unit Tests (`app/src/test/`)
Tests `FormValidator`, `SrtSubtitleGenerator`, `AiResponseValidator`, `ProjectExporter`, and `ProjectRepository` scene ordering:
```bash
./gradlew testDebugUnitTest
```

### Android Instrumented & Compose UI Tests (`app/src/androidTest/`)
Tests Room SQLite persistence (`ProjectDaoInstrumentedTest`) and Compose navigation (`ReelCraftNavigationUiTest`) on a connected device or emulator:
```bash
./gradlew connectedDebugAndroidTest
```

---

## 6. Configuring an AI Provider

1. Open **ReelCraft AI** on your device and tap the **AI Setup (Tune icon)** in the top bar (or navigate via **Settings -> Configure AI Endpoint & API Key**).
2. Choose one of the three modes:
   - **Local Demo Mode (`DEMO_LOCAL`)**: Default. Requires no API key or internet connection. Generates structured Arabic/English sample projects clearly marked as Demo content.
   - **Direct HTTP AI Endpoint (`DIRECT_API`)**: For personal development/testing. Enter an OpenAI-compatible base URL (e.g., `https://api.openai.com/v1/`), model name (e.g., `gpt-4o-mini`), and your API key. The key is stored locally using `EncryptedSharedPreferences` (`AES256_GCM`).
   - **Server-Side Proxy (`SERVER_PROXY`)**: Recommended for production builds distributed to users so no privileged API key is ever placed on client devices. Enter your deployed Supabase Edge Function URL (`https://<project-ref>.supabase.co/functions/v1/generate-script`).

---

## 7. Configuring Supabase (Optional Cloud Backend & Edge Function Proxy)

### Step 1: Apply PostgreSQL Schema & Row Level Security (RLS)
1. Create a new project at [supabase.com](https://supabase.com).
2. Open the **SQL Editor** in your Supabase Dashboard (or use the Supabase CLI) and run:
   ```
   supabase/migrations/20261014000000_init_reelcraft_schema.sql
   ```
   This creates:
   - `public.video_projects` and `public.video_scenes` with `ON DELETE CASCADE`
   - Automatic `updated_at` triggers
   - Strict Row Level Security (RLS) policies enforcing `auth.uid() = user_id` on `SELECT`, `INSERT`, `UPDATE`, and `DELETE` so no user can ever access another user's private projects.

### Step 2: Deploy the Server-Side AI Proxy Edge Function
```bash
supabase login
supabase link --project-ref <your-project-ref>
supabase secrets set AI_API_KEY=sk-your-production-ai-key
supabase secrets set AI_UPSTREAM_URL=https://api.openai.com/v1/chat/completions
supabase functions deploy generate-script
```

### Step 3: Configure Publishable Keys in the App
- In the app's **Settings** screen (or in `local.properties` before building), set:
  - `SUPABASE_URL=https://<your-project-ref>.supabase.co`
  - `SUPABASE_ANON_KEY=<your-publishable-anon-key>`
- **Security Warning**: Never place your Supabase `service_role` key inside `local.properties` or the Android app.
