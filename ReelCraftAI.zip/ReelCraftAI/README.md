# ReelCraft AI (`com.reelcraft.ai`)

**AI Short-Form Video Creator Studio for Android** — Turn video ideas into structured short-form scripts, multi-scene storyboards, AI video-generation prompts, and valid UTF-8 `.SRT` subtitle files.

---

## 1. Overview & Architecture

ReelCraft AI is a modular Android application built with:
- **Language & UI**: 100% Kotlin + Jetpack Compose + Material 3
- **Localization & Layout**: Arabic (`ar`) as the default language with full Right-to-Left (`LayoutDirection.Rtl`) layout support, plus instant switching to English (`en`, LTR) and Light / Dark / System themes
- **Architecture**: Clean MVVM (`data`, `domain`, `ai`, `cloud`, `util`, `ui`) with unidirectional `StateFlow` state management
- **Persistence**: Room SQLite database (`VideoProjectEntity` and `VideoSceneEntity` with `ForeignKey.CASCADE` and indexed search/sort) + Jetpack DataStore (`Preferences`) + `EncryptedSharedPreferences` for local credential protection
- **Networking**: Retrofit 2 + OkHttp 4 + Kotlinx Serialization with an `AiScriptProvider` abstraction supporting:
  1. **Local Demo Mode (`DEMO_LOCAL`)**: Works 100% offline out-of-the-box with clearly labeled sample content (`isDemoContent = true`)
  2. **Direct HTTP AI API (`DIRECT_API`)**: Connects to any OpenAI-compatible `/chat/completions` endpoint
  3. **Server-Side Proxy (`SERVER_PROXY`)**: Connects to the included Supabase Edge Function (`supabase/functions/generate-script/index.ts`) so privileged production API keys remain on the server and are never embedded inside the APK

---

## 2. Screens Implemented (All 10 Required Screens)

| Screen | File | Key Capabilities |
| :--- | :--- | :--- |
| **A. Splash / Initialization** | `ui/screens/SplashScreen.kt` | Initializes Room & DataStore preferences and transitions into the studio |
| **B. Home Dashboard** | `ui/screens/HomeDashboardScreen.kt` | Create New Video CTA, real database project counter, recently edited projects, 4 quick-start templates, search bar, and theme toggle |
| **C. New Video Project Form** | `ui/screens/CreateProjectScreen.kt` | Validated form for title, topic, category (7 options), script language (MSA Arabic, Egyptian Arabic, English), platform (TikTok, Shorts, Reels), duration (30/60/90s), visual style (5 options), scene count (2–12), and custom instructions |
| **D. Script Editor** | `ui/screens/ScriptEditorScreen.kt` | Edit title, opening hook, and full script; live speaking-time estimator; unsaved-changes confirmation dialog on back navigation; copy to clipboard; AI regeneration; `.TXT` export |
| **E. Scene Editor** | `ui/screens/SceneEditorScreen.kt` | Add, edit, delete, and reorder scenes (Move Up / Move Down) with persistent Room database ordering; copy individual video prompts or voice-over text |
| **F. Saved Projects** | `ui/screens/SavedProjectsScreen.kt` | Search across title/topic/script, filter by category, sorted by `updatedAt DESC`, delete confirmation |
| **G. Project Details** | `ui/screens/ProjectDetailsScreen.kt` | Full project metadata summary, Demo vs Live AI badge, script preview, scene list, and direct workspace navigation |
| **H. Settings** | `ui/screens/SettingsScreen.kt` | Switch between Arabic (RTL) and English (LTR), Light/Dark/System theme, default SRT segment duration, optional Supabase configuration, and Clear All Local Data with confirmation |
| **I. AI Provider Configuration** | `ui/screens/AiConfigScreen.kt` | Choose Local Demo Mode, Direct HTTP API, or Server-Side Proxy; configure endpoint URL, model name, and encrypted API key |
| **J. Export & Subtitles** | `ui/screens/ExportScreen.kt` | Interactive `.SRT` subtitle generator with configurable max segment duration, live UTF-8 preview, approximate timing disclaimer, and Storage Access Framework exports (`.TXT` script, `.SRT` subtitles, `.JSON` full project, `.TXT` video prompts) |

---

## 3. Which Features Work Without External Services vs. Require Configuration

### Works Immediately Offline (Zero External Setup Required)
- Creating new projects using **Local Demo Mode** (generates complete Arabic MSA, Egyptian Arabic, or English scripts and multi-scene prompts tailored to your topic and clearly badged as Demo content)
- Using the 4 built-in **Quick-Start Templates**
- Full **Script Editor** (editing title, hook, script, live duration calculation, unsaved changes protection, clipboard copy)
- Full **Scene Editor** (adding, editing, deleting, and reordering scenes with persistent Room SQLite storage)
- **SRT Subtitle Generation** (accurate `HH:MM:SS,mmm --> HH:MM:SS,mmm` formatting, Arabic & English UTF-8 line wrapping, configurable segment duration)
- **File Exports** via Android Storage Access Framework (`.TXT` script, `.SRT` subtitles, `.JSON` full project backup, `.TXT` video prompts) and Android Share Sheet
- **Search, Category Filtering, RTL Arabic / LTR English Switching, and Light/Dark Themes**

### Requires External Credentials or Deployment
- **Live AI Script Generation**: Requires configuring either:
  - A personal OpenAI-compatible endpoint & API key in **AI Provider Configuration** (`DIRECT_API` mode), OR
  - Deploying the included Supabase Edge Function (`supabase/functions/generate-script/index.ts`) and setting `AI_API_KEY` on the server (`SERVER_PROXY` mode, recommended for production).
- **Cloud Database Synchronization (Supabase)**: Requires creating a Supabase project, running `supabase/migrations/20261014000000_init_reelcraft_schema.sql`, and configuring the Supabase Project URL and publishable `anon` key. Cloud sync is optional; local Room storage works independently.

---

## 4. How to Open & Build in Android Studio

See [`BUILD_INSTRUCTIONS.md`](./BUILD_INSTRUCTIONS.md) for step-by-step instructions to:
1. Open the project in Android Studio Ladybug (2024.2.1) or newer with JDK 17
2. Build the debug APK (`./gradlew assembleDebug`)
3. Install the APK on an Android phone via USB debugging (`adb install`)
4. Run unit and instrumented tests (`./gradlew testDebugUnitTest` and `./gradlew connectedDebugAndroidTest`)
5. Deploy the optional Supabase PostgreSQL schema, Row Level Security policies, and Edge Function proxy
